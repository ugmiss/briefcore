//===================================================================================
// Microsoft patterns & practices
// Composite Application Guidance for Windows Presentation Foundation and Silverlight
//===================================================================================
// Copyright (c) Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===================================================================================
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
//===================================================================================
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interactivity;

namespace MVVM.Client.Infrastructure.Behaviors
{
    /// <summary>
    /// Custom behavior that links a <see cref="ValidationSummary"/> control to an object that implements the
    /// <see cref="INotifyDataErroInfo"/> interface to display errors not associated to a bound property.
    /// </summary>
    public class ValidateObject : Behavior<ValidationSummary>
    {
        public static readonly DependencyProperty SourceProperty = DependencyProperty.Register(
          "Source",
          typeof(object),
          typeof(ValidateObject),
          new PropertyMetadata(null, OnSourceObjectChanged));

        public static readonly DependencyProperty PropertyNameProperty = DependencyProperty.Register(
          "PropertyName",
          typeof(string),
          typeof(ValidateObject),
          new PropertyMetadata(null));

        public object Source
        {
            get { return (object)this.GetValue(SourceProperty); }
            set { this.SetValue(SourceProperty, value); }
        }

        public string PropertyName
        {
            get { return (string)this.GetValue(PropertyNameProperty); }
            set { this.SetValue(PropertyNameProperty, value); }
        }

        protected override void OnAttached()
        {
            base.OnAttached();

            this.AttachToSourceObject(null, this.Source);
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();

            this.AttachToSourceObject(this.Source, null);
        }

        private static void OnSourceObjectChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var behavior = d as ValidateObject;
            if (behavior == null)
            {
                throw new ArgumentException("Not a ValidateObject instance", "d");
            }

            if (behavior.AssociatedObject == null)
            {
                return;
            }

            behavior.AttachToSourceObject((INotifyDataErrorInfo)e.OldValue, (INotifyDataErrorInfo)e.NewValue);
        }

        private void AttachToSourceObject(object oldValue, object newValue)
        {
            var oldIndei = oldValue as INotifyDataErrorInfo;
            if (oldIndei != null)
            {
                oldIndei.ErrorsChanged -= this.OnErrorsChanged;
            }

            var newIndei = newValue as INotifyDataErrorInfo;
            if (newIndei != null)
            {
                newIndei.ErrorsChanged += this.OnErrorsChanged;
            }
        }

        private void OnErrorsChanged(object sender, DataErrorsChangedEventArgs args)
        {
            var objectErrors = new List<ValidationSummaryItem>(this.AssociatedObject.Errors);
            foreach (var objectError in objectErrors.Where(e => e.ItemType == ValidationSummaryItemType.ObjectError))
            {
                this.AssociatedObject.Errors.Remove(objectError);
            }

            foreach (var newObjectError in ((INotifyDataErrorInfo)this.Source).GetErrors(this.PropertyName) ?? new object[0])
            {
                this.AssociatedObject.Errors.Add(
                    new ValidationSummaryItem(
                        newObjectError.ToString(),
                        null,
                        ValidationSummaryItemType.ObjectError,
                        null,
                        null));
            }
        }
    }
}

Some of the tests use Moq which can be found here: http://code.google.com/p/moq/
The tests have been built and run against Moq 4.0 beta binaries which can be found here:
http://code.google.com/p/moq/downloads/detail?name=Moq.4.0.10827.zip&can=2&q=

The Moq.dll must be placed in this folder.
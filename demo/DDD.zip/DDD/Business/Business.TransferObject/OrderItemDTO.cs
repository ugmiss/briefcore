﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Business.TransferObject
{
    [DataContract]
    public class OrderItemDTO
    {
        private int _orderItemID;
        private int _orderID;
        private string _goods;
        private double _price;
        private int _count;

        [DataMember]
        public int OrderItemID
        {
            get { return _orderItemID; }
            set { _orderItemID = value; }
        }

        [DataMember]
        public int OrderID
        {
            get { return _orderID; }
            set { _orderID = value; }
        }

        [DataMember]
        public string Goods
        {
            get { return _goods; }
            set { _goods = value; }
        }

        [DataMember]
        public double Price
        {
            get { return _price; }
            set { _price = value; }
        }

        [DataMember]
        public int Count
        {
            get { return _count; }
            set { _count = value; }
        }
    }
}

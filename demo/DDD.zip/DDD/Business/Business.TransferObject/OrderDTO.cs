﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Business.TransferObject
{
    [DataContract]
    public class OrderDTO
    {
        private int _personID;
        private string _name;
        private string _address;
        private string _telephone;
        private int _point;
        private string _email;
        private int _orderID;
        private string _orderNumber;
        private int _count;
        private double _freightage;
        private double _favorable;
        private DateTime _delivery;
        private double _price;
        private double _totalPrice;
        private IList<OrderItemDTO> _orderItemDTOList;

        [DataMember]
        public int PersonID
        {
            get{return this._personID;}
            set{this._personID=value;}
        }
        [DataMember]
        public string Name
        {
            get{return this._name;}
            set{this._name = value;}
        }
        [DataMember]
        public string Address 
        {
            get { return this._address; }
            set { this._address = value; }
        }
        [DataMember]
        public string Telephone 
        {
            get { return this._telephone; }
            set { this._telephone = value; }
        }
        [DataMember]
        public int Point 
        {
            get { return this._point; }
            set { this._point = value; }
        }
        [DataMember]
        public string EMail 
        {
            get { return this._email; }
            set { this._email = value; }
        }
        [DataMember]
        public int OrderID 
        {
            get { return this._orderID; }
            set { this._orderID = value; }
        }
        [DataMember]
        public string OrderNumber 
        {
            get { return this._orderNumber; }
            set { this._orderNumber = value; }
        }
        [DataMember]
        public int Count 
        {
            get { return this._count; }
            set { this._count = value; }
        }
        [DataMember]
        public double Freightage 
        {
            get { return this._freightage; }
            set { this._freightage = value; }
        }
        [DataMember]
        public double Favorable 
        {
            get { return this._favorable; }
            set { this._favorable = value; }
        }
        [DataMember]
        public DateTime Delivery 
        {
            get { return this._delivery; }
            set { this._delivery = value; }
        }
        [DataMember]
        public double Price 
        {
            get { return this._price; }
            set { this._price = value; }
        }
        [DataMember]
        public double TotalPrice 
        {
            get { return this._totalPrice; }
            set { this._totalPrice = value; }
        }
        [DataMember]
        public IList<OrderItemDTO> OrderItemList 
        {
            get { return this._orderItemDTOList; }
            set { this._orderItemDTOList = value; }
        }
    }
}

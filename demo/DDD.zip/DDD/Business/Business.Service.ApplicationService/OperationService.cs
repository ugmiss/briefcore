﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Transactions;
using Business.TransferObject;
using Business.DomainModel;

namespace Business.Service.ApplicationService
{
    public class OperationService:IOperationService
    {
        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        public int AddOrder(ref OrderDTO orderDTO)
        {
            OrderService orderService = new OrderService();
            Order order = GetOrder(orderDTO);
            int n = orderService.AddOrder(order);
            orderDTO = OperationAssembler.GetOrderDTO(order, null);
            return n;
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        public int DeleteOrder(OrderDTO orderDTO)
        {
            OrderService orderService = new OrderService();
            return orderService.DeleteOrder(GetOrder(orderDTO));
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        public int UpdateOrder(ref OrderDTO orderDTO)
        {
            OrderService orderService = new OrderService();
            Order order = GetOrder(orderDTO);
            int n = orderService.UpdateOrder(order);
            orderDTO = OperationAssembler.GetOrderDTO(order, null);
            return n;
        }

        public IList<OrderDTO> GetOrderByPerson(int personID)
        {
            IList<OrderDTO> orderDTOList = new List<OrderDTO>();

            PersonService personService = new PersonService();
            Person person = personService.GetPerson(personID);
            
            OrderService orderService = new OrderService();
            IList<Order> orderList=orderService.GetListByPerson(personID);
            if (orderList.Count() != 0)
            {
                foreach (var order in orderList)
                {
                    OrderDTO orderDTO = OperationAssembler.GetOrderDTO(order, person);
                    orderDTOList.Add(orderDTO);
                }
            }
            return orderDTOList;
        }

        public OrderDTO GetOrder(int orderID)
        {
            OrderService orderService = new OrderService();
            Order order=orderService.GetOrder(orderID);
            PersonService personService = new PersonService();
            Person person = personService.GetPerson(order.PersonID);
            
            return OperationAssembler.GetOrderDTO(order, person);
        }

        public int AddPerson(ref OrderDTO orderDTO)
        {
            PersonService personService = new PersonService();
            Person person = GetPerson(orderDTO);
            int n=personService.AddPerson(person);
            orderDTO = OperationAssembler.GetOrderDTO(null, person);
            return n;
        }

        public int UpdatePerson(ref OrderDTO orderDTO)
        {
            PersonService personService = new PersonService();
            Person person = GetPerson(orderDTO);
            int n=personService.UpdatePerson(person);
            orderDTO = OperationAssembler.GetOrderDTO(null,person);
            return n;
        }

        public OrderDTO GetPerson(int personID)
        {
            PersonService personService=new PersonService();
            Person person = personService.GetPerson(personID);
            return OperationAssembler.GetOrderDTO(null, person);
        }

        public IList<OrderDTO> GetPersonList()
        {
            IList<OrderDTO> orderDTOList = new List<OrderDTO>();
            PersonService personService = new PersonService();
            IList<Person> personList = personService.GetList();
            if (personList.Count != 0)
            {
                foreach (var person in personList)
                {
                    OrderDTO orderDTO = OperationAssembler.GetOrderDTO(null, person);
                    orderDTOList.Add(orderDTO);
                }
            }
            return orderDTOList;
        }

        public OrderDTO Payment(int orderID)
        {
            OrderService orderService = new OrderService();
            var order=orderService.Payment(orderID);
            PersonService personService = new PersonService();
            var person = personService.GetPerson(order.PersonID);
            return OperationAssembler.GetOrderDTO(order, person);
        }

        private Person GetPerson(OrderDTO orderDTO)
        {
            Order order;
            Person person;
            OperationAssembler.SetOrder(orderDTO, out person, out order);
            return person;
        }

        private Order GetOrder(OrderDTO orderDTO)
        {
            Order order;
            Person person;
            OperationAssembler.SetOrder(orderDTO, out person, out order);
            return order;
        }
    }
}

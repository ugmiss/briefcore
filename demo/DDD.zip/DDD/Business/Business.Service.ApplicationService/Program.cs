﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Transactions;

namespace Business.Service.ApplicationService
{
    public class Program
    {
        static void Main(string[] arge)
        {
            Console.WriteLine("************** services start **************");
            ServiceHost host = new ServiceHost(typeof(OperationService));
            host.Open();
            Console.WriteLine("Operation Service Start!");
            Console.ReadKey();
            host.Close();
            Console.WriteLine("Operation Service End!");
        }

        public static void OnComplete(object sender, TransactionEventArgs e)
        {
            Transaction transaction = (Transaction)sender;
            Console.WriteLine("\nTransaction is complete!!!!\nService Order\nLocal:{0}\nDistributed:{1}",
                   transaction.TransactionInformation.LocalIdentifier,
                   transaction.TransactionInformation.DistributedIdentifier);
        }
    }
}

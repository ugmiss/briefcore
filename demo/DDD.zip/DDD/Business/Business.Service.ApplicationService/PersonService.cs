﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Business.IRepository;
using Business.Repository.Factory;
using Business.DomainModel;
using Business.Common;

namespace Business.Service.ApplicationService
{
    public class PersonService
    {
        private IPersonRepository personRepository = DataAccess.CreatePersonRepository();

        public int AddPerson(Person person)
        {
            return personRepository.AddPerson(person);
        }

        public int UpdatePerson(Person person)
        {
            return personRepository.UpdatePerson(person);
        }

        public Person GetPerson(int personID)
        {
            return personRepository.GetPerson(personID);
        }

        public IList<Person> GetList()
        {
            return personRepository.GetList();
        }
    }
}

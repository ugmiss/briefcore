﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Business.DomainModel;
using Business.IRepository;
using Business.Repository;
using Business.Repository.Factory;
using Business.Service.DomainService;

namespace Business.Service.ApplicationService
{
    public class OrderService
    {
        private IOrderRepository orderRepository = DataAccess.CreateOrderRepository();

        public int AddOrder(Order order)
        {
            //计算Order总体费用
            Account(order);
            //加入修改后的Order
            return orderRepository.AddOrder(order);
        }

        public int DeleteOrder(Order order)
        {
            return orderRepository.DeleteOrder(order.ID);
        }

        public Order GetOrder(int orderID)
        {
            return orderRepository.GetOrder(orderID);
        }

        public IList<Order> GetList()
        {
            return orderRepository.GetList();
        }

        public IList<Order> GetListByPerson(int personID)
        {
            return orderRepository.GetListByPerson(personID);
        }

        public int UpdateOrder(Order order)
        {
            Account(order);
            return orderRepository.UpdateOrder(order);
        }

        //确认订单
        public Order Payment(int orderID)
        {
            var order=orderRepository.GetOrder(orderID);
            if (order != null)
            {
                PersonRepository personRepository = new PersonRepository();
                var person=personRepository.GetPerson(order.PersonID);

                PaymentManager paymentManager = new PaymentManager();
                paymentManager.Payment(order, person);

                orderRepository.UpdateOrder(order);
                personRepository.UpdatePerson(person);

                return order;
            }
            else
                throw new Exception("Can not find order!");
        }

        public int AddOrderItem(OrderItem orderItem)
        {
            int index = orderRepository.AddOrderItem(orderItem);
            Order order = orderRepository.GetOrder(orderItem.OrderID);
            UpdateOrder(order);
            return index;
        }

        public int DeleteOrderItem(OrderItem orderItem)
        {
            int index = orderRepository.DeleteOrderItem(orderItem.ID);
            Order order = orderRepository.GetOrder(orderItem.OrderID);
            UpdateOrder(order);
            return index;
        }

        //计算Order总体费用
        private void Account(Order order)
        {
            //获取对应Person对象
            IPersonRepository personRepository = DataAccess.CreatePersonRepository();
            Person person = personRepository.GetPerson(order.PersonID);

            //调用服务层的AccountManager对象，计算费用，修改Order
            AccountManager accountManager = new AccountManager(person, order);
            accountManager.Account();    
        }
    }
}

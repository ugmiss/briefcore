﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Data;
using System.Runtime.Serialization;
using System.Data.Objects.DataClasses;
using Business.DomainModel;
using Business.Common.RepositoryHelp;
using Business.IRepository;
using Business.Repository;
using Business.Repository.Factory;
using Business.Service.DomainService;
using Business.TransferObject;

namespace Business.Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadKey();
        }

        static void OrderServiceTest()
        {
             OrderService.IOrderService orderService = new OrderService.OrderServiceClient();
             var OrderDTO=orderService.GetOrder(4);
        }


        static void DeleteOrder()
        {
            IOrderRepository orderRep = new OrderRepository();
            Order order = orderRep.GetList()[1];
            int n = orderRep.DeleteOrder(order.ID);
        }

        public static void UpdateOrder()
        {
            Order order = null;
            IOrderRepository orderRep = DataAccess.CreateOrderRepository();
            order = orderRep.GetList().First();
            order.Price = 200;
            order.OrderItem.First().Price = 100;
            order.OrderItem.First().Goods = "Kingston 1680";
            int n = orderRep.UpdateOrder(order);
        }

    }
}

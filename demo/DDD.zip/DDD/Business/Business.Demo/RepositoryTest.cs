﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Business.DomainModel;
using Business.Repository;
using Business.Service.DomainService;

namespace Business.Demo
{
    public class RepositoryTest
    {
        //public static void AddOrderTest()
        //{
        //    Order order = new Order();
        //    order.PersonID = 1;
        //    OrderItem item = new OrderItem();
        //    item.Count = 1;
        //    item.Goods = "SWatch E31";
        //    item.Price = 2100;
        //    order.OrderItem.Add(item);

        //    OrderManager orderManager = new OrderManager();
        //    int n=orderManager.AddOrder(order);
        //    Console.WriteLine(order.OrderItem.First().ID);
        //}
    }
}

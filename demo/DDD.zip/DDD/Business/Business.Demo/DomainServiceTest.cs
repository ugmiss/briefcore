﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Business.DomainModel;
using Business.Service.DomainService;

namespace Business.Demo
{
    public class DomainServiceTest
    {
        //public static void UpdateOrder()
        //{
        //    OrderManager manager = new OrderManager();
        //    Order order = manager.GetList().First();

            //OrderItem orderItem = new OrderItem();
            //orderItem.OrderID = 2;
            //orderItem.Count = 2;
            //orderItem.Goods = "Kingston";
            //orderItem.Price = 110;
            //order.OrderItem.Add(orderItem);
            //order.OrderItem.Remove(order.OrderItem.First());
            //int n=manager.UpdateOrder(order);
        //}
    }
}

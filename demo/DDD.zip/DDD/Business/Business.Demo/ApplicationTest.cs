﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Business.Service;
using Business.TransferObject;
using Business.Service.ApplicationService;

namespace Business.Demo
{
    public class ApplicationTest
    {
        public static int AddOrder()
        {
            OrderItemDTO orderItem = new OrderItemDTO();
            orderItem.Count = 1;
            orderItem.Goods = "企业应用架构模式";
            orderItem.Price = 59;

            OrderDTO orderDTO = new OrderDTO();
            IList<OrderItemDTO> list = new List<OrderItemDTO>();
            list.Add(orderItem);
            orderDTO.OrderItemList = list;
            orderDTO.PersonID = 1;

            Business.Service.ApplicationService.OperationService orderSerivce = new Service.ApplicationService.OperationService();
            int n = orderSerivce.AddOrder(ref orderDTO);
            return n;
        }

        public static IList<OrderDTO> GetListByPersonID()
        {
            Business.Service.ApplicationService.OperationService orderSerivce = new Service.ApplicationService.OperationService();
            return  orderSerivce.GetOrderByPerson(1);
        }

        public static OrderDTO GetPerson()
        {
            OperationService operationService = new OperationService();
            OrderDTO orderDTO = operationService.GetPerson(1);
            return orderDTO;
        }
    }
}

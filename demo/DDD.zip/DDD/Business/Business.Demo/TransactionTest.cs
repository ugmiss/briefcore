﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Transactions;

namespace Business.Demo
{
    public class TransactionTest
    {
        public static void Test()
        {
            TransactionScope scope = new TransactionScope();
            Transaction transaction = Transaction.Current;
            if (transaction != null)
                Console.WriteLine("First\nLocal:{0}\nDistributed:{1}",
                    transaction.TransactionInformation.LocalIdentifier,
                    transaction.TransactionInformation.DistributedIdentifier);
            else
                Console.WriteLine("nothing");
            TransactionScope scope2 = new TransactionScope(TransactionScopeOption.RequiresNew);
            Transaction transaction2 = Transaction.Current;
            if (transaction2 != null)
                Console.WriteLine("\nSecond\nLocal:{0}\nDistributed:{1}",
                    transaction2.TransactionInformation.LocalIdentifier,
                    transaction2.TransactionInformation.DistributedIdentifier);
            else
                Console.WriteLine("nothing");
            scope2.Dispose();
            Transaction transaction3 = Transaction.Current;
            if (transaction3 != null)
                Console.WriteLine("\nThird\nLocal:{0}\nDistributed:{1}",
                    transaction3.TransactionInformation.LocalIdentifier,
                    transaction3.TransactionInformation.DistributedIdentifier);
            else
                Console.WriteLine("nothing");
            scope.Complete();
        }
    }
}

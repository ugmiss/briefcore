﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Configuration;
using Business.IRepository;

namespace Business.Repository.Factory
{
    public class DataAccess
    {
          //记录Repository的对象  
        private static Hashtable repositories;  
        //用assemblyString记录Repository程序集的全名称  
        private static string assemblyString = ConfigurationManager.AppSettings["Repository"];  
        private static Assembly assembly;  
  
        static DataAccess()  
        {  
            repositories = new Hashtable();  
            assembly = Assembly.Load(assemblyString);  
        }  
  
        private static object CreateInstance(string typeName)  
        {  
            //当第一次加载时，将反射对象保存于repositories集合里  
            if (!repositories.ContainsKey(typeName))  
            {  
                //创建反射对象  
                object object1 = assembly.CreateInstance(typeName);  
  
                if (object1 == null)  
                    throw new Exception("未能创建此对象");  
                //把对象加入repositories集合  
                repositories["typeName"] = object1;  
            }  
            return repositories["typeName"];  
        }
  
        public static IOrderRepository CreateOrderRepository()  
        {
            return (IOrderRepository)CreateInstance(assemblyString + ".OrderRepository");  
        }

        public static IPersonRepository CreatePersonRepository()
        {
            return (IPersonRepository)CreateInstance(assemblyString + ".PersonRepository");
        }  
    }
}

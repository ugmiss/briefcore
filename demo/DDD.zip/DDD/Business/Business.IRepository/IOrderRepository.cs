﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Business.DomainModel;

namespace Business.IRepository
{
    public interface IOrderRepository
    {
        Order GetOrder(int id);
        IList<Order> GetList();
        IList<Order> GetListByPerson(int personID);
        int AddOrder(Order order);
        int DeleteOrder(int id);
        int UpdateOrder(Order order);
      
        int AddOrderItem(OrderItem orderItem);
        int DeleteOrderItem(int id);
    }
}

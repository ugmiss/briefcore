﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Transactions;
using Business.DomainModel;
using Business.Common.RepositoryHelp;
using Business.IRepository;

namespace Business.Repository
{
    public class PersonRepository:IPersonRepository
    {
        public int AddPerson(Person person)
        {
            return LinqHelp.Add<Person>(person);
        }

        public int AttachPerson(Person person)
        {
            return LinqHelp.Attach<Person>(person);
        }

        public Person GetPerson(int id)
        {
            return LinqHelp.Get<Person>(id);
        }

        public IList<Person> GetList()
        {
            string commandString="SELECT * FROM [Person]";
            return LinqHelp.GetList<Person>(commandString);
        }

        public int UpdatePerson(Person person)
        {
            int returnValue = -1;
            BusinessContext _context = new BusinessContext();

            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    var list = _context.Person
                        .Where(x => x.ID == person.ID);
                    if (list.Count() > 0)
                    {
                        Person _person = list.First();
                        _person.Address = person.Address;
                        _person.EMail = person.EMail;
                        _person.Name = person.Name;
                        _person.Point = person.Point;
                        _person.Telephone = person.Telephone;

                        returnValue = _context.SaveChanges();
                    }
                    else
                        returnValue = 0;
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                Business.Common.ExceptionManager.DataException.DealWith(ex);
                return -1;
            }
            _context.Dispose();
            return returnValue;
        }
    }
}

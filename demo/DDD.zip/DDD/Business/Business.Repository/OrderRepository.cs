﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Transactions;
using Business.Common.RepositoryHelp;
using Business.DomainModel;
using Business.IRepository;

namespace Business.Repository
{
    public class OrderRepository:IOrderRepository
    {
        //根据ID获取单个Order
        public Order GetOrder(int id)
        {
            BusinessContext _context = new BusinessContext();
            Order order = null;

            try
            {
                using (TransactionScope scope = new TransactionScope())
                { 
                    //由于OrderItem是Order实体中的一个属性，必须通过OrderRepository获取
                    var list = _context.Order.Include("OrderItem")
                        .Where(x => x.ID == id);
                    if (list.Count() > 0)
                        order = list.First();
                    else
                        order = new Order();
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                //出错处理，并返回一个空对象
                Business.Common.ExceptionManager.DataException.DealWith(ex);
                order = new Order();
            }
            _context.Dispose();
            return order;
        }

        //获取所有Order
        public IList<Order> GetList()
        {
            BusinessContext _context = new BusinessContext();
            IList<Order> orderList = null;

            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    //由于OrderItem是Order实体中的一个属性，必须通过OrderRepository获取
                    var list = _context.Order.Include("OrderItem");
                    if (list.Count() > 0)
                        orderList = list.ToList();
                    else
                        orderList = new List<Order>();
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                Business.Common.ExceptionManager.DataException.DealWith(ex);
                orderList=new List<Order>();
            }
            _context.Dispose();

            return orderList;
        }

        //获取单个用户的全部Order
        public IList<Order> GetListByPerson(int personID)
        {
            BusinessContext _context = new BusinessContext();
            IList<Order> orderList = null;

            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    //由于OrderItem是Order实体中的一个属性，必须通过OrderRepository获取
                    var list = _context.Order.Include("OrderItem")
                        .Where(x => x.PersonID == personID);
                    if (list.Count() > 0)
                        orderList = list.ToList();
                    else
                        orderList = new List<Order>();
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                Business.Common.ExceptionManager.DataException.DealWith(ex);
                orderList = new List<Order>();
            }
            _context.Dispose();

            return orderList;
        }

        //插入Order
        public int AddOrder(Order order)
        {
            int returnValue = -1;
            BusinessContext _context = new BusinessContext();
        
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    _context.Order.AddObject(order);
                    returnValue = _context.SaveChanges();
                    //保存后重新获取对象，否则在_context释放后无法获得OrderItem属性
                    order = _context.Order.Include("OrderItem")
                        .Where(x => x.ID == order.ID).First();
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                Business.Common.ExceptionManager.DataException.DealWith(ex);
            }

            _context.Dispose();
            return returnValue;
        }

        //删除Order
        public int DeleteOrder(int id)
        {
            int returnValue = -1;
            BusinessContext _context = new BusinessContext();
            
            try
            {
                using (TransactionScope scope = new  TransactionScope())
                {
                    var order = _context.Order.Include("OrderItem")
                        .Where(x => x.ID == id);
                    if (order != null)
                    {
                        //先删除所有的OrderItem，再删除Order
                        foreach (var item in order.First().OrderItem.ToList())
                            LinqHelp.Delete(item.EntityKey);
                        returnValue = LinqHelp.Delete(order.First().EntityKey);
                    }
                    else
                        returnValue = 0;
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                Business.Common.ExceptionManager.DataException.DealWith(ex);
                returnValue=-1;
            }

            _context.Dispose();
            return returnValue;
        }

        //更新Order，因为难以别哪些是原有的OrderItem,哪些OrderItem是新插入
        //使用简单的方法，会先把原有的OrderItem的删除，再重新插入
        public int UpdateOrder(Order order)
        {
            int returnValue = -1;
            BusinessContext _context = new BusinessContext();
           
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    var list = _context.Order.Include("OrderItem")
                        .Where(x => x.ID == order.ID);
                    if (list.Count() > 0)
                    {
                        //更新Order列
                        Order _order = list.First();
                        _order.Count = order.Count;
                        _order.Delivery = order.Delivery;
                        _order.Favorable = order.Favorable;
                        _order.Freightage = order.Freightage;
                        _order.OrderNumber = order.OrderNumber;
                        _order.PersonID = order.PersonID;
                        _order.Price = order.Price;
                        _order.TotalPrice = order.TotalPrice;

                        //删除原有的订单明细项OrderItem
                        if (list.First().OrderItem.Count != 0)
                            foreach (var item in list.First().OrderItem)
                                DeleteOrderItem(item.ID);
                        //加入新的订单明细项OrderItem
                        if (order.OrderItem.Count != 0)
                        {
                            foreach (var item in order.OrderItem)
                            {
                                var _orderItem = new OrderItem();
                                _orderItem.Count = item.Count;
                                _orderItem.Goods = item.Goods;
                                _orderItem.OrderID = item.OrderID;
                                _orderItem.Price = item.Price;
                                AddOrderItem(_orderItem);
                            }
                        }
                        returnValue = _context.SaveChanges();
                    }
                    else
                        returnValue = 0;

                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                Business.Common.ExceptionManager.DataException.DealWith(ex);
                returnValue=-1;
            }

            _context.Dispose();
            return returnValue;
        }

        public int AddOrderItem(OrderItem orderItem)
        {
            return LinqHelp.Add<OrderItem>(orderItem);
        }

        public int DeleteOrderItem(int id)
        {
            EntityKey key = new EntityKey("BusinessContext.OrderItem", "ID", id);
            return LinqHelp.Delete(key);
        }

        /*
        public int UpdateOrderItem(OrderItem item)
        {
            int returnValue = -1;
            BusinessContext _context = new BusinessContext();
            Transaction transaction = Transaction.Current;

            try
            {
                var list = _context.OrderItem
                    .Where(x => x.ID == item.ID);
                if (list.Count() > 0)
                {
                    OrderItem _orderItem = list.First();
                    _orderItem.Count = item.Count;
                    _orderItem.Goods = item.Goods;
                    _orderItem.OrderID = item.OrderID;
                    _orderItem.Price = item.Price;
                    returnValue = _context.SaveChanges();
                }
                else
                    returnValue = 0;
            }
            catch (Exception ex)
            {
                Business.Common.ExceptionManager.DataException.DealWith(ex);
                transaction.Rollback();
                returnValue = -1;
            }

            _context.Dispose();
            return returnValue;
        }  
        */
    }
}

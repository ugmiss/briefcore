﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Business.DomainModel;
using Business.Common;

namespace Business.Service.DomainService
{
    public class AccountManager
    {
        private Person _person;
        private Order _order;

        public AccountManager(Person person, Order order)
        {
            _person = person;
            _order = order;
        }

        ///计算总体收费 
        public void Account()
        {
            //计算商品数量
            GoodsCount();
            //计算商品价格
            PriceAccount();
            //计算优惠等级
            FavorableAccount();
            double price1 = (_order.Price - _order.Favorable).Value;
            //计算运费
            FreightageAccount(price1);
            //计算总体价费
            _order.TotalPrice = price1 + _order.Freightage.Value;
        }

        //计算商品数量
        private void GoodsCount()
        {
            _order.Count=0;
            foreach (var OrderItem in _order.OrderItem)
                _order.Count += OrderItem.Count;
        }
 
        //商品总体价格
        private void PriceAccount()
        {
            _order.Price = 0;
            foreach (var OrderItem in _order.OrderItem)
                _order.Price += OrderItem.Price * OrderItem.Count;
        }

        //优惠分为三等，积分小于1000有9折，小于2000分为8折，大于2000为7折
        private void FavorableAccount()
        {
            int point = (int)_person.Point.GetInt();

            if (point < 1000)
                _order.Favorable = _order.Price * 0.1;
            if (point >= 1000 && point < 2000)
                _order.Favorable = _order.Price * 0.2;
            if (point > 2000)
                _order.Favorable = _order.Price * 0.3;
        }

        //如果价格在98元以上，可免运费。其余运费为10元
        private void FreightageAccount(double price)
        {
            if (price >= 98)
                _order.Freightage = 0;
            else
                _order.Freightage = 10;
        }
    }
}

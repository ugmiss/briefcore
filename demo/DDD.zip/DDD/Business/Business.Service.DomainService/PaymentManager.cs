﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Business.DomainModel;
using Business.IRepository;
using Business.Repository.Factory;

namespace Business.Service.DomainService
{
    public class PaymentManager
    {
        //下单结算
        public void Payment(Order order,Person person)
        {
            //确定下单，建立订单号
            order.OrderNumber = Guid.NewGuid().ToString();
            order.Delivery = DateTime.Now;
            //增加积分
            if (person.Point.HasValue)
                person.Point += (int)order.TotalPrice.GetValueOrDefault();
            else
                person.Point = (int)order.TotalPrice.GetValueOrDefault();
        }
    }
}

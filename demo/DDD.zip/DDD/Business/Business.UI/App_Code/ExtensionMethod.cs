﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///ExtensionMethod 的摘要说明
/// </summary>
public static class ExtensionMethod
{
    public static string GetString(this Object obj)
    {
        if (obj != null)
            return obj.ToString();
        else
            return "暂无";
    }

    public static double GetDouble(this Object obj)
    {
        if (obj != null)
            return double.Parse(obj.ToString());
        else
            return 0.00;
    }
}

//�Ƿ�ȫѡ
var chkid = 0;
//�޹�id
var xiangouid = '31162';

//��ȡ�Ѿ�ɾ����ͼ��
function loaddelbook() {load("#delbook");$.ajax({url: "delbook.asp?action=1",cache: false,success: function(html){$("#delbook").html(html);}}); }
//�����Ѿ�ɾ����ͼ��
function setdelbook() {load("#delbook");$.ajax({url: "delbook.asp?action=0",cache: false,success: function(html){$("#delbook").html(html);}}); }
//��ȡ�����¼
function loadhistory (){load("#history");$.ajax({url: "cart_history.asp",cache: false,success: function(html){$("#history").html(html);}}); }
//��ȡ��¼����
function loadlogin(){$.ajax({url: "login_j.asp",cache: false,success: function(html){$("#logindiv").html(html);}});}
//��ȡ����ҳ��
function cartload(){loadcartbook();loaddelbook();loadhistory()}
//ע���û�
function car_loginout(){$.ajax({url: "http://www.china-pub.com/edition06/logout.asp",cache: false,success: function(html){location.href = 'http://www.china-pub.com/tcart/cart_j.asp' ;}})}
//��ʼ��½����
function login()
{
$("#jianyi").overlay({ 
		start:{top: 'center', width: 400,absolute: false}     ,  
        expose:{color: '#000',opacity: 0.7, closeSpeed: 100 },
        finish: {top: 'center'},    //������ʧ����
		onBeforeLoad : function(){$.ajax({url: "login_j.asp",cache: false,success: function(html){$("#logindiv").html(html);}}); }
    }).load(); 

}
//��¼��֤
function  chklogin()
{
	var zh = escape($('#zh').val());
	var mima = escape($('#mima').val());
	var yzm =escape($('#yzm').val());
	var UserLogin_SaveState = $('#UserLogin_SaveState').val();
	$.ajax({url: 'chklogin.asp?zh='+zh+'&mima='+mima+'&yzm='+yzm+'&UserLogin_SaveState='+UserLogin_SaveState,cache: false,success: function(html){$("#dl_tishi").html(html);if(html=='��ȷ��¼��'){$('#jianyi').overlay().close();location.reload()}}});
}

//ȫѡ��ť
function selectall()
{
	if (chkid==0)
		{chkid =1;$("[name='idarray']").attr("checked",'true');}
	else
		{chkid =0; $("[name='idarray']").removeAttr("checked");}
}

//���ѡ�����Ʒ
function getchk()
{
	var newarrwy  = new Array();
	var sobj = $("[name='idarray']:checked");
	for (var i=0;i<sobj.length;i++){newarrwy.push(sobj[i].value)}
	return newarrwy;
}

//������ʾ���ڵ�����
function cntnt(add,i)
{
	var cb3 = '<table  width="100%" border="0" cellspacing="0" cellpadding="0">'+
	'<tr><td  width="50%" valign="top" ><div class="pp"></div></td>'+
	'<td width="7px" align="center" valign="top"  id="jiao" height="6px">'+
	'<div style="width:5px;"></div><div style="width:4px;"></div>'+
	'<div style="width:3px;"></div><div style="width:2px;"></div>'+
	'<div style="width:1px;"></div><div style="width:0px;"></div></td>'+
	'<td  width="50%" valign="top"><div class="pp"></div></td></tr>'+
	'</table>';
	return "<div id='tipcontent' class='content'>"+add+"</div>"+cb3;
}
//������ʾ��
function showTip(oid)
{
	var x = oid.offset().top;
	var y = oid.offset().left;
	$("#tipdiv").css({position: "absolute", left: y-70 ,top: x-40})
	$('#tipdiv').show();
	$('#tipdiv').html(cntnt(loadimg))
}
function showTip2(oid)
{
	var x = oid.offset().top;
	var y = oid.offset().left;
	$("#tipdiv").css({position: "absolute", left: y+550 ,top: x-48})
	$('#tipdiv').show();
	$('#tipdiv').html(cntnt(loadimg))
}

//������ʾ��
function hidetip(){$('#tipdiv').hide();}

//�Զ�������ʾ��
function autohidetip(){window.setTimeout(hidetip,2000);document.ondblclick=function(){hidetip()};}

//���Ӳ����
function addbookhome(chk,o){

	showTip($('#tb'))
	var selectarray = getchk();
	var addhome = (function(result){$('#tipdiv').html(cntnt(result));autohidetip();});
	if (selectarray.length>0)
	{$.ajax({url: 'add.asp?tushubianhao='+ selectarray.join()+'&typeid=c',cache: false,success:addhome});}
	else
	{$('#tipdiv').html(cntnt('����û��ѡ���鼮��'));autohidetip();}
}
//��������Ʒ
function winpop_new(tushubianhao,o){
	showTip($(o));
	$.ajax({url: 'putcar.asp?tushubianhao='+tushubianhao+'&typeid=c',cache: false,success:function(html){$('#tipdiv').html(cntnt(html));autohidetip();}});	
	window.setTimeout(loadcartbook,2000)
}

//�ָ�ɾ�����ļ�
function winpop_del(tushubianhao,o)
{
showTip($('#delbook'));
$.ajax({url: 'putcar.asp?isdel=1&tushubianhao='+tushubianhao+'&typeid=c',cache: false,success:function(html){$('#tipdiv').html(cntnt(html));autohidetip();}});	
window.setTimeout(loadcartbook,2000)
}

//���ͼ����
function getmoney(gettype)
{	
	var del = false;
	var carttable = $('#tb tr');
	var carttr;
	var num=0,dingjia=0,jiage=0,mayang=0,shiyang =0,sumbook=0,sumzhong=0
	//��֪����ʲô��
	var t ='',t1=''
	var gift=-1,g_td=0;
	sumzhong = carttable.length-3;
	for (var i=1;i<sumzhong+1;i++)
	{
		carttr = $(carttable[i]).find("td");
		dingjia=$(carttr[1]).html().replace('��','').toNum();
		jiage = $(carttr[2]).html().replace('��','').toNum();
		num = $($(carttr[3]).find('input')[0]).val().toNum();
		if (gettype==0)
		{
			t1= $(carttr[1]).html()
			if(t1.indexOf('��')>0&&t1.indexOf('��')>0)
			{
				g_td = i;//gift 's rowindex
				gift++;
				t = dealgift(t1.replace(/<[^>]*>/g,''));
			}
		}
		
		$(carttr[4]).html((jiage*num).toCurr())
		
		mayang +=dingjia*num;
		shiyang+=jiage*num;
		sumbook+=num;
	}
	var nodm=mayang,nogift=mayang;//nogift is the prices without gift
	if($('#num_'+xiangouid).length>0) nodm -= $('#td_dz_'+xiangouid).html().toNum();
	if(gettype==0 && gift>-1) {nogift -= t[2];//nodm -= t[2];
	}
	if(nogift<t[1]) {
		del = true;
		location.replace('view.asp?uid=1fceb6');
		return;
	}
	$('#total_economy').html((mayang-shiyang).toCurr())
	$('#total_account').html(shiyang.toCurr())
	$('#bookzhong').html(sumzhong)
	$('#bookce').html(sumbook)
	try{
		$('#mygift').html(gft(gf,gift,mayang));//reload gift
	}catch(e){}
	return shiyang.toCurr();
}

//ɾ��ͼ��
function del_chek(chk,o)
{
	var selectarray = getchk();
	showTip($('#tb'));
	if (selectarray.length==0){$('#tipdiv').html(cntnt('����ѡ����Ҫɾ������Ʒ��'));autohidetip();return false}
	 var removeSucceed = (function(result)
	 {
		if(result!=null && $.trim(result)!='0')
		{
			for (var i = 0;i<selectarray.length;i++){$('#tr_'+selectarray[i]).remove();}
			var money = getmoney(1);
			var endstr = "ɾ���ɹ���<br/>������Ʒ�ܽ��Ϊ"+money+"Ԫ��";
			$('#tipdiv').html(cntnt(endstr));
			autohidetip();
			setdelbook();
		}
		
	 }
	 )
	 $.ajax({url: 'delabook.asp?act=del&bookid='+ selectarray.join(),cache: false,success:removeSucceed});	
}

//�����޹�ͼ��
function chkxiangou(id,o)
{
	var xiangouobj = document.getElementById('num_'+xiangouid);
	if (xiangouobj&&(id==xiangouobj)&&($.trim(xiangouobj.innerHTML)>5))
	{
		showTip(o);
		$('#tipdiv').html(cntnt('����ƷΪ�޹���Ʒ�������ֻ�ܹ���<span id="lmt">5</span>��'));
		xiangouobj.value = $('bnum_'+xiangouid);
		autohidetip();
		return false;
	}
	return true;

}



//�޸�ͼ������
function up(id,o)
{	
	var num = $.trim($('#num_'+id).val())
	var bnum = $.trim($('#bnum_'+id).val())
	if(parseInt(num)==0||!num.check('^[0-9]{1,3}$')){
		$('#num_'+id).val('1');num=1;
	}
	if(num==bnum) return;
	if(!chkxiangou(id,o)) return;
	var tj = $('#td_tj_'+id).html().toNum();
	var upmoney = (function(result)
	{
		
		switch($.trim(result))
		{
			case "0":
				break;
			case "1":
				
				showTip2($('#tr_'+id));
		
				
				var money = getmoney(0);
				var endstr = "�޸ĳɹ���<br/>������Ʒ�ܽ��Ϊ"+money+"Ԫ��";
				$('#tipdiv').html(cntnt(endstr));
				$('#bnum_'+id).val(num);	
				autohidetip();
				break;
			default: 
			var mr = eval($.trim(result));
			if($.isArray(mr))
			{
				if(mr[0]==2)
				{
					showTip2($('#tr_'+id));
					var endstr = "��治�㣡<br/>�����ֻ����"+mr[1]+"����";
					$('#tipdiv').html(cntnt(endstr));
					$('#num_'+id).val($('#bnum_'+id).val());
					//$('#bnum_'+id).val(mr[1]);
					autohidetip();
				}
			}
			break;
				
		}
	}
	)
	$.ajax({url: 'delabook.asp?act=up&bookid='+id+'&num='+num,cache: false,success:upmoney});	
}

//�ύ����
function toorder()
{
	var booknum = $('#bookce').html().toNum();
	if (booknum==0)
	{
		showTip($('#submitimg')); 
		$('#tipdiv').html(cntnt("���Ĺ��ﳵû����Ʒ��"));
		autohidetip();
	}
	else
	{
	window.location.href="order.asp";
	}
}

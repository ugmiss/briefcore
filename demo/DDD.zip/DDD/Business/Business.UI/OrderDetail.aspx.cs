﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OperationServiceReference;
using Business.TransferObject;

public partial class OrderDetail : System.Web.UI.Page
{
    public OrderDTO orderDTO;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        orderDTO = GetOrder();
        
    }

    private OrderDTO GetOrder()
    {
        int orderID = int.Parse(Request.QueryString["OrderID"]);
        using (OperationServiceClient operationService = new OperationServiceClient())
        {
            orderDTO = operationService.GetOrder(orderID);
           
            if (orderDTO != null)
            {
                if (orderDTO.OrderItemList.Count != 0)
                {
                    Repeater1.DataSource = orderDTO.OrderItemList;
                    Repeater1.DataBind();
                }
                return orderDTO;
            }
            else
                return new OrderDTO();
        }
    }

    public double GetTotal(object price, object count)
    {
        return price.GetDouble() * count.GetDouble();
    }
}
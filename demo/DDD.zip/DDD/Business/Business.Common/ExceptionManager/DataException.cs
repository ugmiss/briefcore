﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Business.Common.ExceptionManager
{
    public class DataException
    {
        public static void DealWith(Exception ex)
        {
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Transactions;
using System.Data.Objects.DataClasses;
using System.Data;
using System.Data.Objects;
using System.Data.Entity;
using System.Reflection;
using Business.DomainModel;

namespace Business.Common.RepositoryHelp
{
    public static class LinqHelp 
    {
        public static int Add<T>(T entity) where T : EntityObject
        {
            int returnValue = -1;
            BusinessContext _context = new BusinessContext();
            
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    _context.AddObject(entity.GetType().Name, entity);
                    returnValue = _context.SaveChanges();
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                Business.Common.ExceptionManager.DataException.DealWith(ex);
            }

            _context.Dispose();
            return returnValue;
        }

        public static int Attach<T>(T entity) where T : EntityObject
        {
            int returnValue = -1;
            BusinessContext _context = new BusinessContext();
           
            try
            {
                using (TransactionScope scope = new  TransactionScope())
                {
                    _context.Attach(entity);
                    returnValue = _context.SaveChanges();
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                Business.Common.ExceptionManager.DataException.DealWith(ex);
            }

            _context.Dispose();
            return returnValue;
        }

        public static int Delete(EntityKey key)
        {
            int n = -1;
            BusinessContext _context = new BusinessContext();
           
            try
            {
                using (TransactionScope scope = new  TransactionScope())
                {
                    var obj = _context.GetObjectByKey(key);
                    if (obj != null)
                        _context.DeleteObject(obj);
                    n = _context.SaveChanges();
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                Business.Common.ExceptionManager.DataException.DealWith(ex);
            }

            _context.Dispose();
            return n;
        }

        public static T Get<T>(int id)
        {
            var returnValue = Activator.CreateInstance<T>();
            BusinessContext _context = new BusinessContext();

            try
            {
                using (TransactionScope scope = new  TransactionScope())
                {
                    string command = string.Format("SELECT * FROM {0} WHERE ID={1} ", 
                        GetTypeName<T>(), id.ToString());
                    var list = _context.ExecuteStoreQuery<T>(command).ToList();
                    if (list.Count() > 0)
                        returnValue = list.First();
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                Business.Common.ExceptionManager.DataException.DealWith(ex);
            }
            _context.Dispose();
            return returnValue;
        }

        private static string GetTypeName<T>()
        {
            string typeName = "["+typeof(T).Name + "]";
            return typeName;
        }

        public static IList<T> GetList<T>(string commandText) 
        {
            IList<T> returnValue = new List<T>();
            BusinessContext _context = new BusinessContext();
 
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    var list = _context.ExecuteStoreQuery<T>(commandText).ToList();
                    if (list.Count() > 0)
                        returnValue = list.ToList();
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                Business.Common.ExceptionManager.DataException.DealWith(ex);
            }
            _context.Dispose();
            return returnValue;
        }
    }
}

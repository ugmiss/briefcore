﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Business.Common
{
    public static class ExtensionMethod
    {
        public static int GetInt(this int n)
        {
            if (n == null)
                return 0;
            else
                return int.Parse(n.ToString());
        }

        public static int GetInt(this int? n)
        {
            if (!n.HasValue)
                return 0;
            else
                return n.Value;
        }

        public static double GetDouble(this double n)
        {
            if (n == null)
                return 0;
            else
                return double.Parse(n.ToString());
        }

        public static double GetDouble(this double? n)
        {
            if (!n.HasValue)
                return 0;
            else
                return n.Value;
        }

        public static string GetString(this string data)
        {
            if (string.IsNullOrEmpty(data))
                return "暂无";
            else
                return data;
        }

        public static int GetInt(this string data)
        {
            if (string.IsNullOrEmpty(data))
                return -1;
            else
                return int.Parse(data);
        }

        public static DateTime GetDateTime(this DateTime datetime)
        {
            if (datetime==null||datetime.Year==0001)
                return DateTime.Parse("0001-00-00 00:00:00");
            else
                return datetime;
        }

        public static DateTime GetDateTime(this DateTime? datetime)
        {
            if (!datetime.HasValue)
            {
                IFormatProvider culture = new System.Globalization.CultureInfo("fr-FR", true);
                return DateTime.Parse("01-01-9999", culture);
            }
            else
                return datetime.Value;
        }
    }
}

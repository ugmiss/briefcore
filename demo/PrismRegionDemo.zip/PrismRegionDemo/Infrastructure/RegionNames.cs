﻿
namespace Infrastructure
{
    public class RegionNames
    {
        public const string NavRegion = "NavRegion";
        public const string MainRegion = "MainRegion";

        public const string NavDemoShowRegion = "NavDemoShowRegion";
        public const string NavDemoActionRegion = "NavDemoActionRegion";

        public const string TabShowRegion = "TabShowRegion";
    }
}

﻿using System;
using System.Windows.Input;
using Microsoft.Practices.Prism.ViewModel;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.Logging;
using Infrastructure;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Prism;

namespace NavigationDemoModule
{
    public class ActionControllerViewModel : NotificationObject
    {
        private IRegionManager _regionManager;
        private IRegion _demoShowRegion;
        private IUnityContainer _container;
        private ILoggerFacade logger;

        public ActionControllerViewModel(IUnityContainer container, IRegionManager regionManager, ILoggerFacade logger)
        {
            _container = container;
            _regionManager = regionManager;
            _demoShowRegion = _regionManager.Regions[RegionNames.NavDemoShowRegion];
            this.logger = logger;
            this.Previous = new DelegateCommand(ToPrevious);
            this.Next = new DelegateCommand(ToNext);
            this.SwitchView = new DelegateCommand<string>(ToSpecifiedView);
        }

        public ICommand Previous { get; private set; }
        public ICommand Next { get; private set; }
        public ICommand SwitchView { get; private set; }

        public bool CanGoBack
        {
            get
            {
                return _demoShowRegion.NavigationService.Journal.CanGoBack;
            }
        }

        public bool CanGoForward
        {
            get
            {
                return _demoShowRegion.NavigationService.Journal.CanGoForward;
            }
        }

        void ToPrevious()
        {
            _demoShowRegion.NavigationService.Journal.GoBack();
            ResetNavigationButtonState();
        }

        void ToNext()
        {
            _demoShowRegion.NavigationService.Journal.GoForward();
            ResetNavigationButtonState();
        }

        void ToSpecifiedView(string viewName)
        {
            UriQuery query = new UriQuery();
            if (viewName == ViewNames.ViewA)
            {
                query.Add("Time", DateTime.Now.ToShortTimeString());
            }
            Uri uri = new Uri(viewName + query.ToString(), UriKind.Relative);
            _regionManager.RequestNavigate(RegionNames.NavDemoShowRegion, uri);
            logger.Log("跳转到视图 [" + viewName + "]", Category.Info, Priority.Low);
            ResetNavigationButtonState();
        }

        void ResetNavigationButtonState()
        {
            RaisePropertyChanged(() => this.CanGoBack);
            RaisePropertyChanged(() => this.CanGoForward);
        }
    }
}

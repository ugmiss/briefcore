﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.Logging;
using Microsoft.Practices.Prism;

namespace NavigationDemoModule
{
    public class ViewAViewModel : INavigationAware
    {
        ILoggerFacade logger;

        public ViewAViewModel(ILoggerFacade logger)
        {
            this.logger = logger;
        }

        public void OnNavigatedTo(NavigationContext navigationContext)
        {
            UriQuery query = navigationContext.Parameters;
            string time = query["Time"];
            logger.Log(string.Format("ViewA: 现在时间 {0}", time), Category.Info, Priority.Medium);
        }

        public bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        public void OnNavigatedFrom(NavigationContext navigationContext)
        {
        }

        
    }
}

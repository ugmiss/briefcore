﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Practices.Prism.Logging;

namespace NavigationDemoModule
{
    public partial class NavigationContainer : UserControl
    {
        ILoggerFacade logger;
        public NavigationContainer(ILoggerFacade logger)
        {
            logger.Log("初始化[导航示例]", Category.Info, Priority.Low);
            InitializeComponent();
            this.logger = logger;
        }
    }
}

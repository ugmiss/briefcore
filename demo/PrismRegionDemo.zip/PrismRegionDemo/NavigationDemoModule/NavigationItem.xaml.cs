﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.Logging;
using System.Text;
using Infrastructure;

namespace NavigationDemoModule
{
    [ViewSortHint("01")]
    public partial class NavigationItem : UserControl
    {
        IRegionManager _regionManager;
        ILoggerFacade logger;

        public NavigationItem(IRegionManager regionManager, ILoggerFacade logger)
        {
            logger.Log("初始化[导航示例]按钮", Category.Info, Priority.Low);
            InitializeComponent();
            this._regionManager = regionManager;
            this.logger = logger;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {           
            Uri uri = new Uri(ViewNames.NavigationContainer, UriKind.Relative);           

            _regionManager.RequestNavigate(RegionNames.MainRegion, uri);
            logger.Log("导航到Navigation示例", Category.Info, Priority.Low);
        }
    }
}

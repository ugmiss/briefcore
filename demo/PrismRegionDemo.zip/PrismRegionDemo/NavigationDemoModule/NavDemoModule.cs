﻿using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.Logging;
using Microsoft.Practices.Prism.Modularity;
using Infrastructure;
using Microsoft.Practices.Unity;

namespace NavigationDemoModule
{
    public class NavDemoModule : IModule
    {
        IRegionManager _regionManager;
        IUnityContainer _container;
        ILoggerFacade logger;

        public NavDemoModule(IUnityContainer container, IRegionManager regionManager, ILoggerFacade logger)
        {
            _container = container;
            _regionManager = regionManager;
            this.logger = logger;
        }

        public void Initialize()
        {
            logger.Log("初始化Navigation模块", Category.Debug, Priority.Low);
            _regionManager.RegisterViewWithRegion(RegionNames.NavRegion, typeof(NavigationItem));
            _regionManager.RegisterViewWithRegion(RegionNames.MainRegion, 
                                                    () => _container.Resolve<NavigationContainer>() );
            _regionManager.RegisterViewWithRegion(RegionNames.NavDemoActionRegion, typeof(ActionController));

            //  注意注册的类型的必须是object，因为Prism无法确定视图的类型，所以就用了object
            _container.RegisterType<object, ViewA>(ViewNames.ViewA);
            _container.RegisterType<object, ViewB>(ViewNames.ViewB);
            _container.RegisterType<object, ViewC>(ViewNames.ViewC);
        }
    }
}

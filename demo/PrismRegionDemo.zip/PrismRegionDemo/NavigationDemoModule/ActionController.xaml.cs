﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Practices.Prism.Logging;
using Microsoft.Practices.Unity;

namespace NavigationDemoModule
{
    public partial class ActionController : UserControl
    {
        public ActionController(ILoggerFacade logger, IUnityContainer container)
        {
            logger.Log("初始化导航示例中的几个按钮的视图", Category.Info, Priority.Low);
            InitializeComponent();

            this.Loaded += (s, e) =>
            {
                this.DataContext = container.Resolve<ActionControllerViewModel>();
            };
        }
    }
}

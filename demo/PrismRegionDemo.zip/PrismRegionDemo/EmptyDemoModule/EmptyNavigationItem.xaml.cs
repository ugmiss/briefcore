﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.Logging;
using Infrastructure;

namespace EmptyDemoModule
{
    [ViewSortHint("02")]
    public partial class EmptyNavigationItem : UserControl
    {
        IRegionManager _regionManager;
        ILoggerFacade logger;

        public EmptyNavigationItem(IRegionManager regionManager, ILoggerFacade logger)
        {
            logger.Log("初始化[空示例]按钮", Category.Info, Priority.Low);
            InitializeComponent();
            this._regionManager = regionManager;
            this.logger = logger;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Uri uri = new Uri(ViewNames.EmptyPage, UriKind.Relative);           

            _regionManager.RequestNavigate(RegionNames.MainRegion, uri);
            logger.Log("导航到Empty示例", Category.Info, Priority.Low);
        }
    }
}

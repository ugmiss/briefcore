﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using ModularityWithUnity.Silverlight;
using Microsoft.Practices.Prism.Logging;
using System.Globalization;

namespace PrismRegionDemo
{
    public partial class PrismRegionShell : UserControl
    {
        public PrismRegionShell(CallbackLogger logger)
        {
            InitializeComponent();
            logger.Callback = Log;
        }

        public void Log(string message, Category category, Priority priority)
        {
            this.LogContainer.Text += string.Format(CultureInfo.CurrentUICulture, "[{0}][{1}] {2}\r\n", category, priority, message);
            //  这段代码的作用是让文本框的滚动条滚动到最底部
            LogContainer.Select(LogContainer.Text.Length, LogContainer.Text.Length);
        }
    }
}

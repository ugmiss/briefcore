﻿using System;
using System.Windows;
using Microsoft.Practices.Prism.UnityExtensions;
using ModularityWithUnity.Silverlight;
using Microsoft.Practices.Prism.Logging;
using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Unity;


namespace PrismRegionDemo
{
    public class Bootstrapper : UnityBootstrapper
    {
        CallbackLogger logger = new CallbackLogger();

        protected override ILoggerFacade CreateLogger()
        {
            return logger;
        }

        protected override IModuleCatalog CreateModuleCatalog()
        {
            return Microsoft.Practices.Prism.Modularity.ModuleCatalog.
                CreateFromXaml(new Uri("/PrismRegionDemo;component/ModulesCatalog.xaml", UriKind.Relative));
        }

        protected override void ConfigureContainer()
        {
            base.ConfigureContainer();
            this.Container.RegisterInstance<CallbackLogger>(logger);
        }

        protected override DependencyObject CreateShell()
        {
            return Container.TryResolve<PrismRegionShell>();
        }

        protected override void InitializeShell()
        {
            App.Current.RootVisual = (UIElement)Shell;
        }
    }
}

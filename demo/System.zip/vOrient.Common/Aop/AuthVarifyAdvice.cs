﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Aop;
using System.Reflection;

namespace vOrient.Common
{
    public class AuthVarifyAdvice : IMethodBeforeAdvice
    {
        public void Before(MethodInfo method, object[] args, object target)
        {
            if (false)
            {
                throw new Exception("没有权限访问");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Aop;
using System.Reflection;
using AopAlliance.Intercept;

namespace vOrient.Common
{
    public class CacheReadAdvice : IMethodInterceptor
    {
        public object Invoke(IMethodInvocation invocation)
        {
            object returnValue = invocation.Proceed();
            //如果缓存过期，从新获取，否则取缓存
            return returnValue;
        }
    }
    public class CacheExpireAdvice : IAfterReturningAdvice
    {
        public void AfterReturning(object returnValue, MethodInfo method, object[] args, object target)
        {
            //通知缓存改变
        }
    }
}

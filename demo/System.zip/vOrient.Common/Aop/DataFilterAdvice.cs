﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AopAlliance.Intercept;

namespace vOrient.Common
{
    public class DataFilterAdvice : IMethodInterceptor
    {
        public object Invoke(IMethodInvocation invocation)
        {
            object returnValue = invocation.Proceed();
            //List<string> li = (List<string>)returnValue;
            //处理数据
            return returnValue;
        }
    }
}

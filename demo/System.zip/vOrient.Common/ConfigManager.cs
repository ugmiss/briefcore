﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace System
{
    public class ConfigManager
    {
        public static Config GetConfig()
        {
            Config config = "".ReadFromFile("Config.xml".AppPath()).XmlDeserialize<Config>();
            return config;
        }
        public static void SaveConfig(Config config)
        {
            config.XmlSerialize().WriteToFile8("Config.xml".AppPath());
        }
        public static string Get(string key)
        {
            //生成默认的配置文件
            //Config configtemp = new Config();
            //configtemp.Items = new List<Item>();
            //configtemp.Items.Add(new Item() { Key = SystemKeys.ConfigDatabase, Value = "server=.;uid=sa;pwd=123456;database=GISData" });
            //SaveConfig(configtemp);
            Config config = "".ReadFromFile("Config.xml".AppPath()).XmlDeserialize<Config>();
            foreach (var item in config.Items)
            {
                if (item.Key == key)
                {
                    return item.Value;
                }
            }
            return null;
        }
    }
    public class Config
    {
        public List<Item> Items { get; set; }
    }
    public class Item
    {
        [XmlAttribute("value")]
        public string Value { get; set; }
        [XmlAttribute("key")]
        public string Key { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Collections.ObjectModel;

namespace vOrient.Common
{
    public static class Mapper
    {
        public static T MapToModel<A, T>(this A data) where T : new()
        {
            T t = new T();
            PropertyInfo[] properties = typeof(T).GetProperties();
            PropertyInfo[] dataprop = typeof(A).GetProperties();
            foreach (PropertyInfo p in properties)
            {
                p.FastSetValue(t, dataprop.FirstOrDefault(p1 => p1.Name == p.Name).FastGetValue(data));
            }
            return t;
        }

        public static ObservableCollection<T> MapToObservableCollection<A, T>(this IEnumerable<A> data) where T : new()
        {
            ObservableCollection<T> list = new ObservableCollection<T>();
            PropertyInfo[] properties = typeof(T).GetProperties();
            PropertyInfo[] dataprop = typeof(A).GetProperties();
            foreach (A o in data)
            {
                T t = new T();
                foreach (PropertyInfo p in properties)
                {
                    var a = dataprop.FirstOrDefault(p1 => p1.Name == p.Name);
                    if (a != null)
                        p.FastSetValue(t, a.FastGetValue(o));
                }
                list.Add(t);
            }
            return list;
        }

        public static List<T> MapToList<A, T>(this IEnumerable<A> data) where T : new()
        {
            List<T> list = new List<T>();

            PropertyInfo[] properties = typeof(T).GetProperties();
            PropertyInfo[] dataprop = typeof(A).GetProperties();

            foreach (A o in data)
            {
                T t = new T();
                foreach (PropertyInfo p in properties)
                {
                    var a = dataprop.FirstOrDefault(p1 => p1.Name == p.Name);
                    if (a != null)
                        p.FastSetValue(t, a.FastGetValue(o));
                }
                list.Add(t);
            }
            return list;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using vOrient.MPS.IRepository;
using vOrient.MPS.DomainModel;
using Spring.Aop.Framework;
using Spring.Aop.Support;
using vOrient.Common;
using Spring.Context;
using Spring.Context.Support;
using System.Collections.Concurrent;

namespace vOrient.MPS.ApplicationService
{
    public class GIS_MineAppService
    {
        IGIS_MineRepository ir;
        public GIS_MineAppService()
        {
            ir = AopFactory.GetProxy<IGIS_MineRepository>();
        }
        public bool AddGIS_Mine(string mineName)
        {
            return ir.Add(new GIS_Mine() { IsValid = true, Name = mineName });
        }
        public List<GIS_Mine> GetGIS_Mine()
        {
            return ir.GetAll();
        }
        
    }
}

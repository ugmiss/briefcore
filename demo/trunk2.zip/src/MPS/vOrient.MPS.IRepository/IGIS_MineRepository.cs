﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using vOrient.MPS.DomainModel;

namespace vOrient.MPS.IRepository
{
    public interface IGIS_MineRepository
    {
        bool Add(GIS_Mine gis_Mine);
        bool Modify(GIS_Mine gis_Mine);
        bool Remove(GIS_Mine gis_Mine);
        List<GIS_Mine> GetAll();
        //int Add<T>(out int IdentityID, T model);
        //int Add<T>(T model);
        //int AddOnly<T>(T t) where T : new();
        //int AddOrModify<T>(T t) where T : new();
        //int Delete<T>(global::System.Linq.Expressions.Expression<Func<T, bool>> func);
        //int Delete<T>(T model);
        //int DeleteAll<T>();
        //global::System.Collections.Generic.List<T> GetAll<T>() where T : new();
        //global::System.Collections.Generic.List<T> GetAll<T>(global::System.Linq.Expressions.Expression<Func<T, bool>> func) where T : new();
        //T GetByPrimaryKey<T>(T model) where T : new();
        //T GetSingle<T>(global::System.Linq.Expressions.Expression<Func<T, bool>> func) where T : new();
        //global::System.Data.DataTable GetTable<T>() where T : new();
        //int Modify<T>(global::System.Linq.Expressions.Expression<Func<T, bool>> func, global::System.Linq.Expressions.Expression<Action<T>> act);
        //int Modify<T>(T model);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using vOrient.MPS.IRepository;
using vOrient.MPS.DomainModel;

namespace vOrient.MPS.Repository
{
    public class GIS_MineRepository : IGIS_MineRepository
    {
        ModelExecuter exec = new ModelExecuter(ConfigManager.Get(SystemKeys.ConfigDatabase));
        public bool Add(GIS_Mine gis_Mine)
        {
            // 泛型自动拼串方式
            int identityid = -1;
            return exec.Add(out identityid, gis_Mine) > 0;
        }
        public bool Modify(GIS_Mine gis_Mine)
        {
            // sql方式 替代return exec.Modify(gis_Mine) > 0;
            return exec.ExecuteNonQuery("update GIS_Mine set Name={0},IsValid={1} where MineID={2}",
                gis_Mine.Name, gis_Mine.IsValid, gis_Mine.MineID) > 0;
        }
        public bool Remove(GIS_Mine gis_Mine)
        {
            // 泛型自动拼串方式
            return exec.Delete(gis_Mine) > 0;
        }
        public List<GIS_Mine> GetAll()
        {
            // 利用快速反射
            return exec.GetAll<GIS_Mine>();
        }
    }
}

using System;
using System.ComponentModel;
using System.Runtime.Serialization;

/* Code Generate Time 2013/4/24 13:23:45*/
namespace vOrient.MPS.DomainModel
{
    [Description("IsTable")]
    [DataContract]
    public class GIS_Mine : ICloneable
    {
        [Description("DataField,IsPrimaryKey,IsIdentity")]
        [DataMember]
        public int MineID { set; get; }
        [Description("DataField")]
        [DataMember]
        public string Name { set; get; }
        [Description("DataField")]
        [DataMember]
        public DateTime CreateTime { set; get; }
        [Description("DataField")]
        [DataMember]
        public bool IsValid { set; get; }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
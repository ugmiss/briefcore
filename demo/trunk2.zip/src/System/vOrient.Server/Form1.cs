﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using vOrient.MPS.ApplicationService;

namespace vOrient.Server
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GIS_MineAppService service = new GIS_MineAppService();
            service.AddGIS_Mine("sss");
            var q= service.GetGIS_Mine();
            service.AddGIS_Mine("aaa");
            var q2 = service.GetGIS_Mine();
            var q3 = service.GetGIS_Mine();
        }
    }
}

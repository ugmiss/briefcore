﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vOrient.Common
{
    /// <summary>
    /// 异常处理。
    /// </summary>
    public class ExceptionManager
    {
       
    }
    /// <summary>
    /// 数据访问异常。
    /// </summary>
    public class DataAccessException : Exception
    {
    }
    /// <summary>
    /// 业务逻辑异常。
    /// </summary>
    public class DomainServiceException : Exception
    {
    }
    /// <summary>
    /// 客户端异常。
    /// </summary>
    public class ClientUIException : Exception
    {
    }
}

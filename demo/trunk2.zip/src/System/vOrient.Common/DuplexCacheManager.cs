﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Concurrent;

namespace vOrient.Common
{
    public delegate void TimeOutChanged(string typename);
    /// <summary>
    /// 基于WCF通知的客户端与服务器双向缓存管理
    /// </summary>
    public static class DuplexCacheManager
    {
        public static event TimeOutChanged OnTimeOutChanged;
        static ConcurrentDictionary<string, bool> TimeOutMap = new ConcurrentDictionary<string, bool>();
        public static bool IsTimeOut<T>()
        {
            if (!TimeOutMap.ContainsKey(typeof(T).ToString()))
                return true;
            return TimeOutMap[typeof(T).ToString()];
        }
        public static bool IsTimeOut(Type t)
        {
            if (!TimeOutMap.ContainsKey(t.ToString()))
                return true;
            return TimeOutMap[t.ToString()];
        }


        public static void NotifyTimeOut(string typename)
        {
            TimeOutMap[typename] = true;
            if (OnTimeOutChanged != null)
            {
                OnTimeOutChanged(typename);
            }
        }
        public static void NotifyTimeOut<T>()
        {
            TimeOutMap[typeof(T).ToString()] = true;
            if (OnTimeOutChanged != null)
            {
                OnTimeOutChanged(typeof(T).ToString());
            }
        }
        public static void NotifyTimeOut(Type t)
        {
            TimeOutMap[t.ToString()] = true;
            if (OnTimeOutChanged != null)
            {
                OnTimeOutChanged(t.ToString());
            }
        }
        public static void AddNotify<T>()
        {
            if (!TimeOutMap.ContainsKey(typeof(T).ToString()))
                TimeOutMap.TryAdd(typeof(T).ToString(), false);
            else
            {
                bool obj;
                TimeOutMap.TryRemove(typeof(T).ToString(), out obj);
                TimeOutMap.TryAdd(typeof(T).ToString(), false);
            }
        }
        public static void AddNotify(Type t)
        {
            if (!TimeOutMap.ContainsKey(t.ToString()))
                TimeOutMap.TryAdd(t.ToString(), false);
            else
            {
                bool obj;
                TimeOutMap.TryRemove(t.ToString(), out obj);
                TimeOutMap.TryAdd(t.ToString(), false);
            }
        }

    }
}

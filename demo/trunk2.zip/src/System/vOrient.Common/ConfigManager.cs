﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace System
{
    public class ConfigManager
    {
        public static OrientConfig GetConfig()
        {
            OrientConfig config = "".ReadFromFile("Config.xml".AppPath()).XmlDeserialize<OrientConfig>();
            return config;
        }
        public static void SaveConfig(OrientConfig config)
        {
            config.XmlSerialize().WriteToFile8("Config.xml".AppPath());
        }
        public static string Get(string key)
        {
            //生成默认的配置文件
            OrientConfig configtemp = new OrientConfig();
            configtemp.Items = new List<Item>();
            configtemp.Items.Add(new Item() { Key = SystemKeys.ConfigDatabase, Value = "server=.;uid=sa;pwd=123456;database=GISData" });
            SaveConfig(configtemp);
            OrientConfig config = "".ReadFromFile("Config.xml".AppPath()).XmlDeserialize<OrientConfig>();
            foreach (var item in config.Items)
            {
                if (item.Key == key)
                {
                    return item.Value;
                }
            }
            return null;
        }
    }
    public class OrientConfig
    {
        public List<Item> Items { get; set; }
    }
    public class Item
    {
        [XmlAttribute("key")]
        public string Key { get; set; }
        [XmlAttribute("value")]
        public string Value { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Context;
using Spring.Context.Support;

namespace vOrient.Common
{
    public class AopFactory
    {
        public static T GetProxy<T>()
        {
            // objectid为spring配置中的objectid系统中默认使用接口名称。
            string objectid = typeof(T).Name;
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (T)ctx[objectid];
        }
    }
}

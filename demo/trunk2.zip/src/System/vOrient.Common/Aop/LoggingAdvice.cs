﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Aop;
using System.Reflection;

namespace vOrient.Common
{
    public class LoggingAdvice : IAfterReturningAdvice
    {
        public void AfterReturning(object returnValue, MethodInfo method, object[] args, object target)
        {
            string successLog = " 执行：" + method.Name + "方法成功";
            Logger.Instance.Info(successLog);//自定义的日志管理类
        }
    }
}

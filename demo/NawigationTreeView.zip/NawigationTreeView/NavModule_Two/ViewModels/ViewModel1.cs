using System;
using System.Linq;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Windows.Data;

using Microsoft.Practices.Prism.ViewModel;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Prism.Regions;

using NavModule_Two.Models;
using NavModule_Two.Services;

namespace NavModule_Two.ViewModels
{
    /// <summary>
    /// ViewModel for View1.
    /// </summary>
    [Export]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public class ViewModel1 : NotificationObject, INavigationAware
    {
        private readonly IDataService _dataService;
        private readonly IEventAggregator _eventAggregator;
        private readonly DataItems _model;

        [ImportingConstructor]
        public ViewModel1(IDataService dataService, IEventAggregator eventAggregator)
        {
            _dataService = dataService;
            _eventAggregator = eventAggregator;

            // Get the data model from the data service.
            _model = _dataService.GetModel();

            // Initialize the CollectionView for the underlying model
            // and track the current selection.
            DataItemsCV = new ListCollectionView(_model);
            DataItemsCV.CurrentChanged += new EventHandler(SelectedItemChanged);

            // Initialize this ViewModel's commands.
            Command1 = new DelegateCommand<string>(ExecuteCommand1, CanExecuteCommand1);
        }

        public DataItem CurrentItem { get; private set; }

        #region DataItems CollectionView

        public ICollectionView DataItemsCV { get; private set; }

        private void SelectedItemChanged(object sender, EventArgs e)
        {
            // Update the command status.
            Command1.RaiseCanExecuteChanged();
        }
        #endregion

        #region Command1
        public DelegateCommand<string> Command1 { get; private set; }

        private void ExecuteCommand1(string commandParameter)
        {
            DataItem item = DataItemsCV.CurrentItem as DataItem;
            if (item != null)
            {
                // Update the current item.
                CurrentItem = DataItemsCV.CurrentItem as DataItem;
                base.RaisePropertyChanged<DataItem>(() => CurrentItem);
            }
        }

        private bool CanExecuteCommand1(string commandParameter)
        {
            // Command is only enabled when an item is selected.
            return DataItemsCV.CurrentItem != null;
        }

        #endregion

        #region INavigationAware Members
        public bool IsNavigationTarget(NavigationContext navigationContext)
        {
            // Called to see if this view can handle the navigation request.
            // If it can, this view is activated.
            return true;
        }

        public void OnNavigatedFrom(NavigationContext navigationContext)
        {
            // Called when this view is deactivated as a result of navigation to another view.
        }

        public void OnNavigatedTo(NavigationContext navigationContext)
        {
            // Called to initialize this view during navigation.

            // Retrieve any required paramaters from the navigation Uri.
            string id = navigationContext.Parameters["ID"];
            if (!string.IsNullOrEmpty(id))
            {
                DataItem item = _dataService.GetModel().FirstOrDefault(dataItem => dataItem.Id == id);
            }
        }
        #endregion
    }
}

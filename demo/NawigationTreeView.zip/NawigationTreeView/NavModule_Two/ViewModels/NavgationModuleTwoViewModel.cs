﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Prism.ViewModel;
using System.ComponentModel.Composition;
using NavInfrastructure;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.Commands;

namespace NavModule_Two.ViewModels
{
    /// <summary>
    /// Main navigation class of the Module_Two.
    /// </summary>
    [Export]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public class NavigationModuleTwoViewModel : NotificationObject
    {

        IRegionManager _regionManager;
    
        [ImportingConstructor]
        public NavigationModuleTwoViewModel(IRegionManager regionManager)
        {
            this._regionManager = regionManager;
            // Initialize this ViewModel's commands. 
            // The command occurs upon request to an item
            SelectedCommand = new DelegateCommand<object>(SelectedExecute);
        }

        #region Property Root and helper methods
        private EntityBase _root;
        public EntityBase Root // Populate in NavigationDocumentsViewModel_PropertyChanged
        {
            get { return _root ?? new Catalog() { Title = "Module two", IDEntity=-1 }; }
            set
            {
                if (value != _root)
                {
                    _root = value;
                    this.RaisePropertyChanged("Root");
                }
            }
        }
        #endregion
        #region SelectedCommand
        public DelegateCommand<object> SelectedCommand { get; private set; }
        private void SelectedExecute(object commandParameter)
        {
            if (commandParameter != null)
            {
                EntityBase obj = commandParameter as EntityBase;
                if (obj != null)
                {
                    //Catalog cat = obj as Catalog;
                    //if (cat != null)
                    //{
                    //    string addressView = QueryStringBuilder.Construct(ViewsName.CatalogView, new[,] { { ViewsName.ParentId, obj.IDEntity.ToString() } });
                    //    _regionManager.RequestNavigate(NameRegions.MainRegion, addressView, Callback);
                    //}
                    //else
                    //{
                    //    string addressView = QueryStringBuilder.Construct(ViewsName.DocumentView, new[,] { { ViewsName.ParentId, obj.IDEntity.ToString() } });
                    //    _regionManager.RequestNavigate(NameRegions.MainRegion, addressView, Callback);
                    //}
                }
            }
            else // Is Root 
            {

            }

        }      
        #endregion
    }
}

using System;
using System.ComponentModel.Composition;

using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.MefExtensions.Modularity;
using Microsoft.Practices.ServiceLocation;

using NavModule_Two.Views;
using NavModule_Two.Services;
using NavInfrastructure;

namespace NavModule_Two
{
    [ModuleExport("NavModule_Two.ModuleInit", typeof(NavModule_Two.ModuleInit))]
    public class ModuleInit : IModule
    {
        private readonly IRegionManager _regionManager;
        public IServiceLocator _serviceLocator;

        [ImportingConstructor]
        public ModuleInit(IRegionManager regionManager, IServiceLocator serviceLocator)
        {
            _regionManager = regionManager;
            _serviceLocator = serviceLocator;
        }

        #region IModule Members

        public void Initialize()
        {
            // Use View Discovery to automatically display the MasterView when the TopLeft region is displayed.
            _regionManager.RegisterViewWithRegion(NameRegions.NavigationTreeViewRegion, () => _serviceLocator.GetInstance<NavigationModuleTwoView>());
        }

        #endregion
    }
}

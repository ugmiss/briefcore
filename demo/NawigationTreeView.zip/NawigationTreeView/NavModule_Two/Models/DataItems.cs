using System;
using System.Collections.ObjectModel;

namespace NavModule_Two.Models
{
    /// <summary>
    /// Collection class for data items.
    /// </summary>
    public class DataItems : ObservableCollection<DataItem>
    {
    }
}

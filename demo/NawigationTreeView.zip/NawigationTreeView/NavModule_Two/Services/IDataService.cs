using System;

using NavModule_Two.Models;

namespace NavModule_Two.Services
{
    /// <summary>
    /// Data service interface.
    /// </summary>
    public interface IDataService
    {
        DataItems GetModel();
    }
}

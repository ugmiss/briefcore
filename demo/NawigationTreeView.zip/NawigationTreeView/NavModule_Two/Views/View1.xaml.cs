using System;
using System.ComponentModel.Composition;
using System.Windows.Controls;

using NavModule_Two.ViewModels;

namespace NavModule_Two.Views
{
    [Export]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public partial class View1 : UserControl
    {
        public View1()
        {
            InitializeComponent();
        }

        [Import(AllowRecomposition = false)]
        public ViewModel1 ViewModel
        {
            get { return this.DataContext as ViewModel1; }
            set { this.DataContext = value; }
        }
    }
}

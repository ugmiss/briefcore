﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using NavInfrastructure;
using System.Windows.Interactivity;
using System.ComponentModel.Composition;
using NavModule_Two.ViewModels;

namespace NavModule_Two.Views
{
    [Export]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class NavigationModuleTwoView : TreeViewItem
    {
        #region .ctor's
        public NavigationModuleTwoView()
        {
            InitializeComponent();
        }
        #endregion

        #region SetComponent
        void InitializeComponent()
        {
            this.SetBinding(ItemsSourceProperty, new Binding() { Path = new PropertyPath("ContentTable") });
            this.HeaderTemplate = GetHeaderTemplate();
            this.SetBinding(HeaderProperty, new Binding() { Path = new PropertyPath("Root") });
            this.ItemTemplate = this.GetHierarchicalTemplate();
            this.Resources.Add("hierarchicalTemplate", this.ItemTemplate);
        }

        private DataTemplate GetHeaderTemplate()
        {
            DataTemplate dataTemplate = new DataTemplate(typeof(EntityBase));

            //create stack pane;
            FrameworkElementFactory stackPanel = new FrameworkElementFactory(typeof(StackPanel));
            stackPanel.Name = "headerStackPanel";
            stackPanel.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);
            stackPanel.SetBinding(StackPanel.ToolTipProperty, new Binding());

            // Create Image 
            FrameworkElementFactory icon = new FrameworkElementFactory(typeof(ContentPresenter));
            icon.SetValue(ContentPresenter.MarginProperty, new Thickness(2));
            icon.SetBinding(ContentPresenter.ContentProperty, new Binding() { Path = new PropertyPath("Icon"), Converter = StringToImage.Default });
            stackPanel.AppendChild(icon);

            // create text
            FrameworkElementFactory titleLabel = new FrameworkElementFactory(typeof(TextBlock));
            titleLabel.SetValue(TextBlock.TextProperty, new Binding("Title"));
            titleLabel.SetValue(TextBlock.FontWeightProperty, FontWeights.Bold);
            titleLabel.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            stackPanel.AppendChild(titleLabel);

            //set the visual tree of the data template
            dataTemplate.VisualTree = stackPanel;
            return dataTemplate;
        }
        private HierarchicalDataTemplate GetHierarchicalTemplate()
        {
            //create the data template
            HierarchicalDataTemplate dataTemplate = new HierarchicalDataTemplate(typeof(EntityBase));

            //create stack pane;
            FrameworkElementFactory stackPanel = new FrameworkElementFactory(typeof(StackPanel));
            stackPanel.Name = "parentStackpanel";
            stackPanel.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);
            stackPanel.SetBinding(StackPanel.ToolTipProperty, new Binding());

            // Create Image as ContentPresenter
            FrameworkElementFactory content = new FrameworkElementFactory(typeof(ContentPresenter));
            content.SetValue(ContentPresenter.MarginProperty, new Thickness(2));
            content.SetBinding(ContentPresenter.ContentProperty, new Binding() { Path = new PropertyPath("Icon"), Converter = StringToImage.Default });
            stackPanel.AppendChild(content);

            // create text
            FrameworkElementFactory titleLabel = new FrameworkElementFactory(typeof(TextBlock));
            titleLabel.SetBinding(TextBlock.TextProperty, new Binding() { Path = new PropertyPath("Title") });
            titleLabel.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            stackPanel.AppendChild(titleLabel);

            //set the visual tree of the data template
            dataTemplate.VisualTree = stackPanel;
            dataTemplate.ItemsSource = new Binding() { Path = new PropertyPath("SubEntity") };
            return dataTemplate;
        }
        #endregion

        #region Setting DataContext
        private NavigationModuleTwoViewModel _viewModel;
        [Import]
        public NavigationModuleTwoViewModel ViewModel // 
        {
            get { return _viewModel; }
            set
            {
                _viewModel = value;
                this.DataContext = _viewModel;
                // Samemu trzeba zadbać o właściwe dopisanie innych zadań
                Populate();
            }
        }
        #endregion

        #region Help Method
        // Inne zadania
        private void Populate()
        {
            /* In Xaml appears so:
            <i:Interaction.Triggers>
                <i:EventTrigger EventName="Selected">
                    <i:InvokeCommandAction Command="{Binding SelectedCommand}"
                                           CommandParameter="{Binding Path=SelectedItem, RelativeSource={RelativeSource  AncestorType={x:Type TreeView}}}" />
                </i:EventTrigger>
            </i:Interaction.Triggers>
            */
            // In Procedural Code:
            InvokeCommandAction iCASelect = new InvokeCommandAction();
            iCASelect.SetValue(InvokeCommandAction.CommandProperty, this._viewModel.SelectedCommand);
            BindingOperations.SetBinding(iCASelect,
                InvokeCommandAction.CommandParameterProperty,
                new Binding()
                {
                    Path = new PropertyPath("SelectedItem"),
                    RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(TreeView), 1)
                });

            var eventTriggerSelect = new System.Windows.Interactivity.EventTrigger("Selected");//or MouseDubleClick
            eventTriggerSelect.Actions.Add(iCASelect);

            var triggerColl = Interaction.GetTriggers(this);
            triggerColl.Add(eventTriggerSelect);
        }
        #endregion
    }
}

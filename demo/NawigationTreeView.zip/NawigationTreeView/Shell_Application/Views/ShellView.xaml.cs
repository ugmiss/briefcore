using System;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel.Composition;

using NavShell.ViewModels;

namespace NavShell.Views
{
    [Export]
    public partial class ShellView : Window
    {
        public ShellView()
        {
            InitializeComponent();
        }

        [Import(AllowRecomposition = false)]
        public ShellViewModel ViewModel
        {
            get { return this.DataContext as ShellViewModel; }
            set { this.DataContext = value; }
        }
    }
}

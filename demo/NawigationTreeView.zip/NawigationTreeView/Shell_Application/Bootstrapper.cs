using System;
using System.Windows;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;

using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Prism.MefExtensions;

using NavShell.Views;

namespace NavShell
{
    public partial class Bootstrapper : MefBootstrapper
    {
        protected override IModuleCatalog CreateModuleCatalog()
        {
            // Create the module catalog from a XAML file.
            return Microsoft.Practices.Prism.Modularity.ModuleCatalog.CreateFromXaml(
                        new Uri("/NavigateTreeView;component/ModuleCatalog.xaml", UriKind.Relative));
        }

        protected override void ConfigureAggregateCatalog()
        {
            base.ConfigureAggregateCatalog();

            // Add this assembly to the catalog.
            this.AggregateCatalog.Catalogs.Add(new AssemblyCatalog(typeof(Bootstrapper).Assembly));

            // Modules are located in the shell's directory. Both module projects have
            // a post-build step that copies the module assemblies into this directory.
            DirectoryCatalog catalog = new DirectoryCatalog(".");
            this.AggregateCatalog.Catalogs.Add(catalog);
        }

        protected override void ConfigureContainer()
        {
            base.ConfigureContainer();
        }

        protected override DependencyObject CreateShell()
        {
            // Use the container to create an instance of the shell.
            ShellView shell = this.Container.GetExportedValue<ShellView>();

            // Display the shell's root visual.
            shell.Show();

            return shell;
        }
    }
}


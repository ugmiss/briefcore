Prism WPF 4.0 Shell Project
---------------------------

Next Steps:
Compile and run!

Note:
Prism 4.0 provides signed binary assemblies. To ensure that project references are resolved correctly,
register the Prism assemblies with Visual Studio by running the RegisterPrismBinaries batch file.

For the latest information on Prism, see www.codeplex.com/prism.



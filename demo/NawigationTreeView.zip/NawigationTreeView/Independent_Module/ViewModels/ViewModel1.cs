using System;
using System.Linq;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Windows.Data;

using Microsoft.Practices.Prism.ViewModel;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Prism.Regions;

using Independent_Module.Models;
using Independent_Module.Services;
using Microsoft.Practices.ServiceLocation;

namespace Independent_Module.ViewModels
{
    /// <summary>
    /// ViewModel for View1.
    /// </summary>
    [Export]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public class ViewModel1 : NotificationObject, INavigationAware
    {
        private readonly IDataService _dataService;
        private readonly IEventAggregator _eventAggregator;
        private readonly DataItems _model;

        [ImportingConstructor]
        public ViewModel1(IDataService dataService, IEventAggregator eventAggregator)
        {
            _dataService = dataService;
            _eventAggregator = eventAggregator;

            // Get the data model from the data service.
            _model = _dataService.GetModel();

            // Initialize the CollectionView for the underlying model
            // and track the current selection.
            DataItemsCV = new ListCollectionView(_model);
            DataItemsCV.CurrentChanged += new EventHandler(SelectedItemChanged);

            // Initialize this ViewModel's commands.
            Command1 = new DelegateCommand<string>(ExecuteCommand1, CanExecuteCommand1);
        }

        public DataItem CurrentItem { get; private set; }

        #region DataItems CollectionView

        public ICollectionView DataItemsCV { get; private set; }

        private void SelectedItemChanged(object sender, EventArgs e)
        {
            // Update the command status.
            Command1.RaiseCanExecuteChanged();
        }
        #endregion

        #region Command1
        public DelegateCommand<string> Command1 { get; private set; }

        private void ExecuteCommand1(string commandParameter)
        {
            DataItem item = DataItemsCV.CurrentItem as DataItem;
            if (item != null)
            {
                // Update the current item.
                CurrentItem = DataItemsCV.CurrentItem as DataItem;
                base.RaisePropertyChanged<DataItem>(() => CurrentItem);
            }
        }

        private bool CanExecuteCommand1(string commandParameter)
        {
            // Command is only enabled when an item is selected.
            return DataItemsCV.CurrentItem != null;
        }

        #endregion

        #region INavigationAware Members
        public bool IsNavigationTarget(NavigationContext navigationContext)
        {
            // Called to see if this view can handle the navigation request.
            // If it can, this view is activated.
            return true;
        }

        public void OnNavigatedFrom(NavigationContext navigationContext)
        {
            // Called when this view is deactivated as a result of navigation to another view.
        }

        public void OnNavigatedTo(NavigationContext navigationContext)
        {
            // Called to initialize this view during navigation.

            // Retrieve any required paramaters from the navigation Uri.
            string id = navigationContext.Parameters["ID"];
            if (!string.IsNullOrEmpty(id))
            {
                DataItem item = _dataService.GetModel().FirstOrDefault(dataItem => dataItem.Id == id);
            }
        }
        #endregion

        #region Killing behavior
        public virtual DelegateCommand<object> KillingCommand
        {
            get { return _killingCommand ?? (_killingCommand = new DelegateCommand<object>(KillView)); }
            set { _killingCommand = value; }
        }
        private DelegateCommand<object> _killingCommand;
        public virtual void KillView(object view)
        {
            // Arbitrary Container.
            IRegionManager manager = ServiceLocator.Current.GetInstance<IRegionManager>();
            // find and remove view.
            foreach (IRegion region in manager.Regions)
            {
                // Find current view
                // Ustalamy obiekt na li�cie widok�w
                object removeView = region.Views.SingleOrDefault(v => v == view);
                if (removeView != null)
                    // Remove finding view.
                    // Usuwamy ustalony widok.
                    manager.Regions[region.Name].Remove(view);
            }
        }
        #endregion
    }
}

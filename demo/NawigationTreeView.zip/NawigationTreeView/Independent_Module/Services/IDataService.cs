using System;

using Independent_Module.Models;

namespace Independent_Module.Services
{
    /// <summary>
    /// Data service interface.
    /// </summary>
    public interface IDataService
    {
        DataItems GetModel();
    }
}

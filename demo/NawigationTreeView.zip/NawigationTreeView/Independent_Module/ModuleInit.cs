using System;
using System.ComponentModel.Composition;

using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.MefExtensions.Modularity;
using Microsoft.Practices.ServiceLocation;

using Independent_Module.Views;
using Independent_Module.Services;

namespace Independent_Module
{
    [ModuleExport("Independent_Module.ModuleInit", typeof(Independent_Module.ModuleInit))]
    public class ModuleInit : IModule
    {
        private readonly IRegionManager _regionManager;
        public IServiceLocator _serviceLocator;

        [ImportingConstructor]
        public ModuleInit(IRegionManager regionManager, IServiceLocator serviceLocator)
        {
            _regionManager = regionManager;
            _serviceLocator = serviceLocator;
        }

        #region IModule Members

        public void Initialize()
        {
            // Use View Discovery to automatically display the MasterView when the TopLeft region is displayed.
            _regionManager.RegisterViewWithRegion("NavigationTreeViewRegion", () => _serviceLocator.GetInstance<NavigationIntependentModuleView>());
        }

        #endregion
    }
}

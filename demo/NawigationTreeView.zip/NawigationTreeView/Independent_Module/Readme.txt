Prism WPF 4.0 Module Project
----------------------------

Next Steps:
Update this project's post-build event to copy the module assembly to your Shell project.

Note:
Prism 4.0 provides signed binary assemblies. To ensure that project references are resolved correctly,
register the Prism assemblies with Visual Studio by running the RegisterPrismBinaries batch file.

For the latest information on Prism, see www.codeplex.com/prism.



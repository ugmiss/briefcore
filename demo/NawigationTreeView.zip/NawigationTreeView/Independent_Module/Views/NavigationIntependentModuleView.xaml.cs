﻿using System;
using System.ComponentModel.Composition;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Practices.Prism.Regions;

namespace Independent_Module.Views
{
    /// <summary>
    /// Interaction logic for NavigationIntependentModuleView.xaml
    /// </summary>
    [Export]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public partial class NavigationIntependentModuleView : UserControl
    {
        public NavigationIntependentModuleView()
        {
            InitializeComponent();
        }

        [Import]
        Lazy<IRegionManager> RegionManager { get ;set ; }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            IRegionManager _regionManager = RegionManager.Value;
            _regionManager.RequestNavigate("MainRegion", "Independent_Module.Views.View1");
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Click button 2");
        }
      
    }
}

﻿using System;

namespace NavInfrastructure
{
    public static class NameRegions
    {
        public static string NavigationTreeViewRegion = "NavigationTreeViewRegion";
        public static string MainRegion = "MainRegion";
    }
}

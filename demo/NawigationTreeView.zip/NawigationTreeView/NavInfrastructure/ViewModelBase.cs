﻿using System.Linq;

using Microsoft.Practices.Prism.ViewModel;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.ServiceLocation;

namespace NavInfrastructure
{
    public abstract class ViewModelBase : NotificationObject
    {
        #region Killing behavior
        public virtual DelegateCommand<object> KillingCommand
        {
            get { return _killingCommand ?? (_killingCommand = new DelegateCommand<object>(KillView)); }
            set { _killingCommand = value; }
        }
        private DelegateCommand<object> _killingCommand;
        public virtual void KillView(object view)
        {
            // Arbitrary Container.
            IRegionManager manager = ServiceLocator.Current.GetInstance<IRegionManager>();
            // find and remove view.
            foreach (IRegion region in manager.Regions)
            {
                // Find current view
                // Ustalamy obiekt na liście widoków
                object removeView = region.Views.SingleOrDefault(v => v == view);
                if (removeView != null)
                    // Remove finding view.
                    // Usuwamy ustalony widok.
                    manager.Regions[region.Name].Remove(view);
            }
        }
        #endregion
    }

}


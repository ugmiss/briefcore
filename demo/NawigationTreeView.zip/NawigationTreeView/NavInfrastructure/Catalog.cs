﻿using System.Collections.Generic;

namespace NavInfrastructure
{
    public class Catalog : EntityBase
    {
        public IEnumerable<EntityBase> SubEntity { get; set; }
    }
}

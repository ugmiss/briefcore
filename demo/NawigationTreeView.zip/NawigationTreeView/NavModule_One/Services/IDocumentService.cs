﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NavInfrastructure;

namespace NavModule_One.Services
{
   public interface IDocumentService
    {
       void GetDocumentsAndCatalogs(Action<IEnumerable<EntityBase>, Exception> loadCallback);
    }
}

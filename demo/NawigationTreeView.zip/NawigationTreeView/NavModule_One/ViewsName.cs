﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NavModule_One
{
    public static class ViewsName
    {

        public const string CatalogView = "CatalogView";
        public const string DocumentView = "DocumentView";
        public const string ParentId = "ParentId";
        public const string NavigationModule = "NavigationModuleOne";

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Microsoft.Practices.Prism.ViewModel;
using System.Collections.ObjectModel;
using NavInfrastructure;
using NavModule_One.Services;
using System.Diagnostics;

namespace NavModule_One.Models
{
    [Export]
    public class CacheManager : NotificationObject
    {
        private readonly IDocumentService _service;
        private ObservableCollection<EntityBase> _cacheDocuments;
        public ObservableCollection<EntityBase> CacheDocuments // 
        {
            get { return _cacheDocuments; }
            set
            {
                _cacheDocuments = value;
                this.RaisePropertyChanged("CacheDocuments");
            }
        }
        [ImportingConstructorAttribute]
        public CacheManager(IDocumentService service)
        {
            if (service == null) throw new ArgumentNullException("service");
            this._service = service;
            this._service.GetDocumentsAndCatalogs(LoadCompleted);
            // Initilalize empty Collection Documents
            this._cacheDocuments = new ObservableCollection<EntityBase>();
        }
        // Callback Loader completed or Error.
        private void LoadCompleted(IEnumerable<EntityBase> entites, Exception error)
        {
            if (error == null)
            {
                // Kill using
                this.CacheDocuments.Clear();
                // New populate
                this.CacheDocuments = entites as ObservableCollection<EntityBase>;
            }
            else
            {
                OnError(error);
            }
        }
        private void OnError(Exception error)
        {
            // TODO: To do writing log to logger.
            Debug.WriteLine(error.Message);
            throw new Exception("Callback Loader completed with Error.", error);
        }
    }
}

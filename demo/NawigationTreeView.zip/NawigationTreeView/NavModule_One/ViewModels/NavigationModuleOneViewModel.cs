﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Diagnostics;
using System.Linq;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.ViewModel;
using NavInfrastructure;
using NavModule_One.Models;
using NavModule_One.Properties;

namespace NavModule_One.ViewModels
{
    /// <summary>
    /// Main navigation class of the Module_One.
    /// </summary>
    [Export]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public class NavigationModuleOneViewModel : NotificationObject
    {
        #region Declaration field class
        CacheManager _cacheManager;
        IRegionManager _regionManager;
        #endregion
        #region .ctor
        /// <summary>
        /// Default Mef .ctor. Called when creating an object constructor.
        /// </summary>
        /// <param name="cacheManager">The data cache manager.</param>
        /// <param name="regionManager">The Regions manager.</param>
        [ImportingConstructor] // Called when creating an object constructor
        public NavigationModuleOneViewModel(
            CacheManager cacheManager, // Initialization of the data cache manager
            IRegionManager regionManager // Initialization of the Regions manager
            )
        {
            if (cacheManager == null) throw new ArgumentNullException("cacheManager");
            if (regionManager == null) throw new ArgumentNullException("regionManager");
            this._cacheManager = cacheManager;
            this._regionManager = regionManager;

            _categories = new ObservableCollection<EntityBase>();
            // Get the data model from the Cache but wait how will be populated.
            ((NotificationObject)_cacheManager).PropertyChanged += new PropertyChangedEventHandler(NavigationDocumentsViewModel_PropertyChanged);

            // Initialize this ViewModel's commands. 
            // The command occurs upon request to an item
            SelectedCommand = new DelegateCommand<object>(SelectedExecute, CanExecuteSelected);
        }
        #endregion
        #region Property CurrentCategory and ...
        public EntityBase CurrentCategory { get; private set; }
        #endregion
        #region Property Root and helper methods
        private EntityBase _root;
        public EntityBase Root // Populate in NavigationDocumentsViewModel_PropertyChanged
        {
            get { return _root ?? new Catalog() { Title = Strings.LoadingModuleMessage }; }
            set
            {
                if (value != _root)
                {
                    _root = value;
                    this.RaisePropertyChanged("Root");
                }
            }
        }
        #endregion
        #region Property Categories and helper methods
        private ObservableCollection<EntityBase> _categories;
        public ObservableCollection<EntityBase> Categories { get { return _categories; } }
        #endregion
        #region Helper methods
        void NavigationDocumentsViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "CacheDocuments")
            {
                Populate();
                // Po każdym resecie Documents (Przypisanie nowej kolekcji usuwa również subskrybcje)
                // przypisujemy Subskrybcje na zdarzenia zmian w kolekcji.
                _cacheManager.CacheDocuments.CollectionChanged += new NotifyCollectionChangedEventHandler(CacheDocuments_CollectionChanged);
            }
        }
        void CacheDocuments_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems != null || e.OldItems != null)
                Populate();
        }
        void Populate()
        {
            PopulateRoot();
            this.Categories.Clear();
            foreach (var i in PopulateItemCategories(_root.IDEntity))
            {
                Categories.Add(i);
            }
        }
        void PopulateRoot()
        {
            this.Root = this._cacheManager.CacheDocuments.Single(i => i.Parent == null);
            if (string.IsNullOrEmpty(Root.Icon)) this.Root.Icon = Settings.Default.RootIcon;
        }
        IEnumerable<EntityBase> PopulateItemCategories(int idParent)
        {
            var tempItem = this._cacheManager.CacheDocuments.Where(i => i.Parent != null && i.Parent.IDEntity == idParent);
            foreach (var e in tempItem)
            {
                Catalog cat = e as Catalog;
                if (cat != null)
                {
                    cat.SubEntity = PopulateItemCategories(e.IDEntity);
                }
            }
            return tempItem;
        }
        #endregion
        #region SelectedCommand
        public DelegateCommand<object> SelectedCommand { get; private set; }
        private void SelectedExecute(object commandParameter)
        {
            if (commandParameter != null)
            {
                EntityBase obj = commandParameter as EntityBase;
                if (obj != null)
                {
                    Catalog cat = obj as Catalog;
                    if (cat != null)
                    {
                        string addressView = QueryStringBuilder.Construct(ViewsName.CatalogView, new[,] { { ViewsName.ParentId, obj.IDEntity.ToString() } });
                        _regionManager.RequestNavigate(NameRegions.MainRegion, addressView, Callback);
                    }
                    else
                    {
                        _regionManager.RequestNavigate(NameRegions.MainRegion, QueryStringBuilder.Construct(ViewsName.DocumentView, new[,] { { ViewsName.ParentId, obj.IDEntity.ToString() } }), Callback);
                    }
                }
                else
                {
                    // First level.
                    if (_root != null)
                    {
                        string addressView = QueryStringBuilder.Construct(ViewsName.CatalogView, new[,] { { ViewsName.ParentId, _root.IDEntity.ToString() } });
                        _regionManager.RequestNavigate(NameRegions.MainRegion, addressView, Callback);
                    }
                }
            }
        }
        private bool CanExecuteSelected(object commandParameter)
        {
            return true;
        }
        #endregion
        #region Navigation helper
        void Callback(NavigationResult result)
        {
            // Todo: To do log.
            Debug.WriteLine("NavigationResult: {0}", result.Result);
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using NavModule_One.ViewModels;
using System.ComponentModel.Composition;

namespace NavModule_One.Views
{
    /// <summary>
    /// Interaction logic for DocumentView.xaml
    /// </summary>
    [Export("DocumentView", typeof(DocumentView))]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public partial class DocumentView : UserControl
    {
        //[ImportingConstructor]
        //public DocumentView(DocumentViewModel viewModel):this()
        //{ 
        //    this.DataContext = viewModel;
        //}

        public DocumentView()
        {
            InitializeComponent();
        }
        [Import]
        public DocumentViewModel ModelView
        {
            get { return (DocumentViewModel)this.DataContext; }
            set { this.DataContext = value; }
        }
    }
}

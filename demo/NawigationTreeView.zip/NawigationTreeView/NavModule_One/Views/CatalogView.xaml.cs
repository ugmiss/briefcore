﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel.Composition;
using NavModule_One.ViewModels;

namespace NavModule_One.Views
{
    /// <summary>
    /// Interaction logic for Catalog.xaml
    /// </summary>
    [Export("CatalogView", typeof(CatalogView))]
    public partial class CatalogView : UserControl
    {
        [ImportingConstructor]
        public CatalogView(CatalogViewModel modelView)
            : this()
        {
            this.DataContext = modelView;
        }
        public CatalogView()
        {
            InitializeComponent();
        }
        //[Import]
        //public CatalogViewModel ModelView
        //{
        //    get { return (CatalogViewModel)this.DataContext; }
        //    set { this.DataContext = value; }
        //}
    }
}

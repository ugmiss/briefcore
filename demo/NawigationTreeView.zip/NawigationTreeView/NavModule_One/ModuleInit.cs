using System;
using System.ComponentModel.Composition;

using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.MefExtensions.Modularity;
using Microsoft.Practices.ServiceLocation;

using NavModule_One.Views;
using NavInfrastructure;

namespace NavModule_One
{
    [ModuleExport("NavModule_One.ModuleInit", typeof(NavModule_One.ModuleInit))]
    public class ModuleInit : IModule
    {
        private readonly IRegionManager _regionManager;
        public IServiceLocator _serviceLocator;

        [ImportingConstructor]
        public ModuleInit(IRegionManager regionManager, IServiceLocator serviceLocator)
        {
            _regionManager = regionManager;
            _serviceLocator = serviceLocator;
        }

        #region IModule Members

        public void Initialize()
        {
            // Use View Discovery to automatically display the MasterView when the TopLeft region is displayed.
            _regionManager.RegisterViewWithRegion(NameRegions.NavigationTreeViewRegion, () => _serviceLocator.GetInstance<NavigationModuleOneView>());
        }

        #endregion
    }
}

﻿using Microsoft.Windows.Controls.Ribbon;

namespace Prism4Demo.Shell.Views
{
    /// <summary>
    /// Interaction logic for ShellWindow.xaml
    /// </summary>
    public partial class ShellWindow : RibbonWindow
    {
        public ShellWindow()
        {
            InitializeComponent();

            // Insert code required on object creation below this point.
        }
    }
}
